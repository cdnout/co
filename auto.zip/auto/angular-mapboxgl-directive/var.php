<?php 
//$npm_check = "";
$keyfiles_add = array("angular-mapboxgl-directive.min.css");
$version_limit = "-10";
$type_s = "jquery";
?>
