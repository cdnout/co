<?php 
$npm_check = "angular-material";
$keyfiles_add = array("angular-material.min.js");
$version_limit = "-10";
$type_s = "angular";
?>
