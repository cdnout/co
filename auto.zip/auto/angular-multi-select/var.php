<?php 
$npm_check = "angular-multi-select";
$keyfiles_add = array("isteven-multi-select.min.css");
$version_limit = "-10";
$type_s = "angular";
?>
