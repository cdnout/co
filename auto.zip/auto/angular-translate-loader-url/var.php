<?php 
$npm_check = "angular-translate-loader-url";
$keyfiles_add = array("");
$version_limit = "-10";
$type_s = "angular";
?>
