<?php 
$npm_check = "angular-highlight-js@2.0.0";
$keyfiles_add = array("");
$version_limit = "-10";
$type_s = "jquery";
?>
