<?php 
ini_set('max_execution_time', 30000);
set_time_limit(30000);
$version_linit = "";
$listfolders = "";
//include("var.php");
// function entire directory
function custom_copy($src, $dst) {
    // open the source directory 
    $dir = opendir($src);  
    // Make the destination directory if not exist 
    @mkdir($dst);  
    // Loop through the files in source directory 
    foreach (scandir($src) as $file) {  
        if (( $file != '.' ) && ( $file != '..' )) {  
            if ( is_dir($src . '/' . $file) ) {
              custom_copy($src . '/' . $file, $dst . '/' . $file); 
            }  
            else {  
                copy($src . '/' . $file, $dst . '/' . $file);  
            }
        }
    }  
   
    closedir($dir);  
  }

// function delete dir
function delete_directory($dirname) {
           if (is_dir($dirname))
             $dir_handle = opendir($dirname);
       if (!$dir_handle)
            return false;
       while($file = readdir($dir_handle)) {
             if ($file != "." && $file != "..") {
                  if (!is_dir($dirname."/".$file))
                       unlink($dirname."/".$file);
                  else
                       delete_directory($dirname.'/'.$file);
             }
       }
       closedir($dir_handle);
       rmdir($dirname);

  }
 
// function scan
  function recursiveScan($dir, $listfolders, $listfiles, $thefolder) {
      $tree = glob(rtrim($dir, '/') . '/*');
      if (is_array($tree)) {
          foreach($tree as $file) {
            $filename = substr($file, strrpos($file, '/') + 1);
              
              if (is_dir($file)) {
              if(!empty($listfolders)) {
                foreach ($listfolders as $value) {
                  $umd_js = glob($dir.$value.'/*');
                  foreach($umd_js as $key_dist => $file_dist) {
                    $file_dist;
                    $filename2 = substr($file_dist, strrpos($file_dist, '/') + 1);
                    $forward_paths = "../../$thefolder/$filename2";
                    if(!file_exists($forward_paths)) {
                      copy($file_dist,$forward_paths);
                    }
                  }
                }
              }
              recursiveScan($file, $listfolders, $listfiles, $thefolder);
              } elseif (is_file($file)) {

                if(!empty($listfiles)) {
                foreach ($listfiles as $value) {
                  
                  
                  if($filename == $value) {
                    $forward_paths = "../../$thefolder/$filename"; 
                    $fileext = pathinfo($filename, PATHINFO_EXTENSION);
                    //print_r($fileextension);
                    
                      
                      if($fileext != "woff" && $fileext != "woff2" && $fileext != "svg" && $fileext != "eot" && $fileext != "ttf" && $fileext != "otf" && $fileext != "jpg" && $fileext != "gif" && $fileext != "png" && $fileext != "webp" ){
                        if(!file_exists($forward_paths)) {
                          copy($file,$forward_paths);
                        }
                      } else {
                        if($fileext == "jpg" or $fileext == "gif" or $fileext == "png" or $fileext == "webp"){
                        $forward_paths = "../../$thefolder/img/$filename";
                        if(!file_exists("../../$thefolder/img/")){
                          mkdir("../../$thefolder/img", 0777, true);
                        }
                        if(!file_exists($forward_paths)) {
                          copy($file,$forward_paths);
                        }
                      }
                      if($fileext == "woff" or $fileext == "woff2" or $fileext == "eot" or $fileext == "ttf" or $fileext == "otf"){
                        $forward_paths = "../../$thefolder/fonts/$filename";
                        if(!file_exists("../../$thefolder/fonts/")){
                          mkdir("../../$thefolder/fonts", 0777, true);
                        }
                        if(!file_exists($forward_paths)) {
                          copy($file,$forward_paths);
                        }                        
                      }
                        
                        /*
                      if($fileext == "scss"){
                        $forward_paths = "../../$thefolder/scss/$filename";
                          if(!file_exists("../../$thefolder/scss/")){
                            mkdir("../../$thefolder/scss", 0777, true);
                          }
                          if(!file_exists($forward_paths)) {
                            copy($file,$forward_paths);
                          }
                        
                      }
                      if($fileext == "less"){
                        $forward_paths = "../../$thefolder/less/$filename";
                        
                        if(!file_exists("../../$thefolder/less/")){
                            mkdir("../../$thefolder/less", 0777, true);
                          }
                          if(!file_exists($forward_paths)) {
                            copy($file,$forward_paths);
                          }
                      }*/
                      }
                  }
                }                  
              }
            }
          }
        }
      }

// download remore filesize
function download_remote_file($file_url, $save_to){
		$content = file_get_contents($file_url);
		file_put_contents($save_to, $content);
	}

function dir_is_empty($dir) {
  $handle = opendir($dir);
  while (false !== ($entry = readdir($handle))) {
    if ($entry != "." && $entry != "..") {
      closedir($handle);
      return FALSE;
    }
  }
  closedir($handle);
  return TRUE;
}

// start the work
include "var.php";

$filess = glob("./" . '*.txt');
$filess2 = implode("/", $filess);
$filess2 = explode("/", $filess2);            
$version_file = end($filess2);


$foldername_sp_ = explode("@", $version_file); 
$folderexit_ = $foldername_sp_[count($foldername_sp_) -2]; 
$v_h_latest = $foldername_sp_[count($foldername_sp_) -1];
echo $v_h_latest = substr($v_h_latest, 0, strpos($v_h_latest, ".txt"));

$json_url = "https://api.cdnjs.com/libraries/$folderexit_";
$get_headers = get_headers($json_url);
$get_headers = current($get_headers);
if($get_headers != "HTTP/1.1 404 Not Found") {
$json = file_get_contents($json_url);   
$data = json_decode($json, TRUE);
$article_folder = "../../cdn/$folderexit_";
 $director = $data['name'];
  $data_descr = $data['description'];
  $data_github = $data['repository']['url'];
  $data_version = $data['version'];
  $data_keywords = $data['keywords'];
  $data_keyfiles = $data['filename'];
  if(isset($data['autoupdate']) && $data['autoupdate']['source'] == "npm") {
    $data_npm = $data['autoupdate']['target'];
    
  }
  //$folder_name = $director;
  
  if(file_exists("package.json")) {
    
    $current_data = file_get_contents("package.json");  
    $array_data = json_decode($current_data, true);  
    $extra = array(  
         'name'            =>    $director,  
         'version'         =>    $data_version,
         'description'     =>    $data_descr,
         'repository'      =>    $data_github,
         'keyfiles'        =>    $data_keyfiles,
         'keywords'        =>    $data_keywords,
         'npm'        =>    $data_npm
    );  
    $array_data[] = $extra;  
    $final_data = json_encode($array_data);  
    if(file_put_contents("package.json", $final_data))  
    {  
         $message = "<label class='text-success'>File Appended Success fully</p>";  
    } 
  }
$data_keyfiles_list = explode(",", $data_keyfiles);
  if(!empty($keyfiles_add)) {
  $data_keyfiles_list = array_merge($data_keyfiles_list, $keyfiles_add);
}
$file_keeper_folder = "../../$director";
$file_keeper_folder_stay = "../../$director";
  
if($v_h_latest  != $data_version || (!file_exists($file_keeper_folder))) {
  echo $file_renewel = "true";
} else{ 
  echo $file_renewel = "false";
}

$json_main_url = "https://api.cdnjs.com/libraries/$director/$data_version";
$json_main = file_get_contents($json_main_url);   
$json_main_data = json_decode($json_main, TRUE);
$files_list = $json_main_data['files'];

if(isset($file_keeper_folder)) {
if(file_exists($file_keeper_folder)){ 
  if($file_renewel == "true") {
    delete_directory("$file_keeper_folder");
    mkdir($file_keeper_folder, 0777, true);
    echo "folder update done";
  }
} else {
  mkdir($file_keeper_folder, 0777, true); 
  echo "folder done"."<br>";
} 
}


foreach($files_list as $file_ext) {
  $file_ext_i = explode("/", $file_ext);
  $count_folders = count($file_ext_i);
  if($count_folders == 4)  {
    $inner_folder_name = current($file_ext_i);
    $inner_folder_name2 = $file_ext_i[1];
    $inner_folder_name3 = $file_ext_i[2];
    if(!file_exists($inner_folder_name)){ 
      mkdir($file_keeper_folder.'/'.$inner_folder_name.'/'.$inner_folder_name2.'/'.$inner_folder_name3, 0777, true); 
    }
  }
 if($count_folders == 3)  {
    $inner_folder_name = current($file_ext_i);
    $inner_folder_name2 = $file_ext_i[1];
    if(!file_exists($inner_folder_name)){ 
      mkdir($file_keeper_folder.'/'.$inner_folder_name.'/'.$inner_folder_name2, 0777, true); 
    }
  }
  if($count_folders == 2) {
     $inner_folder_name = current($file_ext_i);
    if(!file_exists("$inner_folder_name")){
      mkdir($file_keeper_folder.'/'.$inner_folder_name, 0777, true);
    }
  }      
  $file_ext_filename = end($file_ext_i);
  $file_ext_final = pathinfo($file_ext_filename, PATHINFO_EXTENSION);
}
foreach($data_keyfiles_list as $file_ext) {
  $file_ext_i = explode("/", $file_ext);
  $file_ext_filename = end($file_ext_i);
  $file_ext_final = pathinfo($file_ext_filename, PATHINFO_EXTENSION);
 
  if($file_ext_final == "css") {
    $key_css_file_list[] = $file_ext;
    
  }
  if($file_ext_final == "js") {
    $key_js_file_list[] = $file_ext;
  }
  if($file_ext_final == ".map") {
    
  }
}
if(isset($key_js_file_list)) {
echo $index_js_file = $key_js_file_list[0];  
}
  
  if(isset($key_css_file_list)) {
echo $index_css_file = $key_css_file_list[0];
  }
  
if($file_renewel == "true") {
  foreach($files_list as $file_ext) {
    $file_ext_i = explode("/", $file_ext);
    $file_ext_filename = end($file_ext_i);
    $file_ext_final = pathinfo($file_ext_filename, PATHINFO_EXTENSION);
    
    
    if(count($file_ext_i) > 1) {
      $folderPath = str_replace($file_ext_filename, "", $file_ext);
      $folderPath = $file_keeper_folder."/".$folderPath;
    } else {
      $folderPath = $file_keeper_folder; 
    }
    if($file_ext_final != "map" && file_exists($folderPath)) {
      $file_to_copy = "https://cdnjs.cloudflare.com/ajax/libs/$director/$data_version/$file_ext";
      download_remote_file($file_to_copy, realpath("$folderPath") . "/$file_ext_filename");
    }
  }
  
}
  foreach($files_list as $file_ext) {
    $file_ext_i = explode("/", $file_ext);
    $file_ext_filename = end($file_ext_i);
  if(isset($index_js_file)) {
    $js_ext_i = explode("/", $index_js_file);
    $js_ext_i_filename = end($js_ext_i);
    if($js_ext_i_filename == $file_ext_filename) {
      copy("$file_keeper_folder/$file_ext","$file_keeper_folder/index.js");
    }
  }
   
  if(isset($index_css_file)) {
    $css_ext_i = explode("/", $index_css_file);
    $css_ext_i_filename = end($css_ext_i);
    if(!file_exists("$file_keeper_folder/css/")) {
      mkdir("$file_keeper_folder/css", 0777, true);
    }
    if($css_ext_i_filename == $file_ext_filename) {
      copy("$file_keeper_folder/$file_ext","$file_keeper_folder/css/base.css");
    }
  }
  }

// creating template files for latest version
if(file_exists($article_folder)){ 
  delete_directory("$article_folder");
  mkdir($article_folder, 0777, true);
  copy("../main-template.php","$article_folder/index.php");
  copy("package.json","$article_folder/package.json");
  copy("var.php","$article_folder/var.php");
  copy("$version_file","$article_folder/$version_file");
  echo "Main article folder update done";
} else {
  mkdir($article_folder, 0777, true);
  copy("../main-template.php","$article_folder/index.php");
  copy("package.json","$article_folder/package.json");
  copy("var.php","$article_folder/var.php");
  copy("$version_file","$article_folder/$version_file");
  echo "Main article folder done"."<br>";
}
// creating zip for latest version
if(!file_exists("../../zip/$director.zip") || $file_renewel == "true") {
  
$rootPath = realpath("$file_keeper_folder");

// Initialize archive object
$zip = new ZipArchive();
$zip->open("../../zip/$director.zip", ZipArchive::CREATE | ZipArchive::OVERWRITE);

// Create recursive directory iterator

$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($rootPath),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($files as $name => $file) {
  // Skip directories (they would be added automatically)
  if (!$file->isDir()) {
    // Get real and relative path for current file
    $filePath = $file->getRealPath();
    $relativePath = substr($filePath, strlen($rootPath) + 1);

    // Add current file to archive
    $zip->addFile($filePath, $relativePath);
  }
}

// Zip archive will be created only after closing object
$zip->close();
}

// creating other versions template folders
$json_versions = "https://api.cdnjs.com/libraries/$director?fields=versions";


$json_main_v = file_get_contents($json_versions);   
$json_version_data = json_decode($json_main_v, TRUE);
$version_list = $json_version_data['versions'];
foreach($version_list as $key => $one) {
  if(strpos($one, 'alpha') !== false) {
    unset($version_list[$key]);
  }
  if(strpos($one, 'beta') !== false) { 
    unset($version_list[$key]);
  }
  if(strpos($one, 'rc') !== false) { 
    unset($version_list[$key]);
  }
  if(strpos($one, 'dev') !== false) { 
    unset($version_list[$key]);
  }
  if(strpos($one, 'insiders') !== false) { 
    unset($version_list[$key]);
  }
  if(strpos($one, '-pre') !== false) { 
    unset($version_list[$key]);
  }
  if(strpos($one, 'test') !== false) { 
    unset($version_list[$key]);
  }
  if(strpos($one, 'pre') !== false) { 
    unset($version_list[$key]);
  }
}
if(!empty($version_limit)) {
  $versions_slice = array_slice($version_list, $version_limit);  
} else {
  $versions_slice = $version_list;
}
foreach($versions_slice as $version_as) {
  $version_folder = $article_folder."@".$version_as;
    if(file_exists($version_folder)){ 
    delete_directory("$version_folder");
    mkdir($version_folder, 0777, true);
    copy("../main-template.php","$version_folder/index.php");
    echo "$version_limit Versions Updated"."<br>";
  } else {
    mkdir($version_folder, 0777, true);
    copy("../main-template.php","$version_folder/index.php");
    echo "$version_limit Versions Updated"."<br>";
  }
} 
print_r($versions_slice);
}
//print_r($css_file_list);
//print_r($js_file_list);
//print_r($font_file_list);
//print_r($img_file_list);
      // CDN AI
      //print_r($listfiles);
      // Getting Versions
    /*  $commas = "'";
      $get_v =  shell_exec("npm v $director_ versions");
      $get_v = str_replace('[', '', $get_v);
      $get_v = str_replace(']', '', $get_v);      
      $get_v = str_replace($commas, '', $get_v);      
      $get_v_ar_b  = explode(',', $get_v); 
      foreach($get_v_ar_b as $key => $one) {
        if(strpos($one, 'alpha') !== false) {
          unset($get_v_ar_b[$key]);
        }
        if(strpos($one, 'beta') !== false) { 
          unset($get_v_ar_b[$key]);
        }
        if(strpos($one, 'rc') !== false) { 
          unset($get_v_ar_b[$key]);
        }
        if(strpos($one, 'dev') !== false) { 
          unset($get_v_ar_b[$key]);
        }
        if(strpos($one, 'insiders') !== false) { 
          unset($get_v_ar_b[$key]);
        }
        if(strpos($one, '-pre') !== false) { 
          unset($get_v_ar_b[$key]);
        }
      }

       
      $get_v_ar_full = $get_v_ar_b;
      
      $get_v_ar = $get_v_ar_b;
    
      $get_v_ar = array_slice($get_v_ar, -1); 
      
      print_r($get_v_ar); 
      //array_pop($get_v_ar_full);
      
  
      if(!empty($version_limit)) {
        $get_v_ar_full = array_slice($get_v_ar_full, $version_limit);  
      }

      $get_v_ar_breed = $get_v_ar_b;
      print_r($get_v_ar_full);
      
      $latest_version = end($get_v_ar);
      $latest_version = preg_replace('/\s+/', '', $latest_version);
if(isset($myfiles)) {
  $listfiles = $listfiles;
} else {

 $json_url = "https://api.cdnjs.com/libraries/$fileNameSpecial/$latest_version";
$get_headers = get_headers($json_url);
$get_headers = current($get_headers);
if($get_headers != "HTTP/1.1 404 Not Found") {
  $json = file_get_contents($json_url);   
  $data = json_decode($json, TRUE);
  $file_cnn = $data['files'];
}
foreach($file_cnn as $filecn){
   
  if(!empty($filecn)){
    $listfiles_ar = substr($filecn, strrpos($filecn, '/'));
    $listfiles_ar = str_replace('/', '', $listfiles_ar);
    $listfiles_ar = preg_replace('/\s+/', '', $listfiles_ar);
    $listfiles_arr[] = $listfiles_ar;
  }
}
  

 
$listfiles = $listfiles_arr;
print_r($listfiles);
}

      // deleting files
  if(!isset($version_lock)) {
      foreach($get_v_ar_breed as $key => $version) {
          $version = preg_replace('/\s+/', '', $version);
          $foldersname = $director."@".$version;
        if(file_exists("../../$director")) {
        delete_directory("../../$director");
        delete_directory("../../cdn/$director");
        unlink("../../zip/$director.zip");
        }
        if(file_exists("../../$foldersname")) {
        delete_directory("../../$foldersname");
        delete_directory("../../cdn/$foldersname"); 
        unlink("../../zip/$foldersname.zip");     
      }
      }
  }
      // NPM Installation
      foreach($get_v_ar as $key => $version) {
          $version = preg_replace('/\s+/', '', $version);
          $foldersname = $director;
        
          if(!file_exists($foldersname)) {
            shell_exec("cd $foldersname");
            mkdir("$foldersname", 0777, true);
            copy("package.json","$foldersname/package.json"); 
            shell_exec("cd $foldersname && npm install $director_");
          }        
      }
      // File Copying
      
      foreach($get_v_ar as $key => $version) {
            
            $version = preg_replace('/\s+/', '', $version);
            
            $foldersname = $director;  
            $mainarticle = "../../cdn/$foldersname";
            $mainfolder = "../../$foldersname";
            // folder creation
            if(file_exists($mainfolder)) {
              delete_directory("../../$foldersname");
              mkdir("../../$foldersname", 0777, true);
            } else {
              mkdir("../../$foldersname", 0777, true);
            }
            
            if(file_exists($mainarticle)) {
              delete_directory("../../cdn/$foldersname");
             
              mkdir("../../cdn/$foldersname", 0777, true);
              
            } else {
              mkdir("../../cdn/$foldersname", 0777, true);
              
            }
        if(file_exists($mainarticle)) {
         $myfile = fopen("$mainarticle/$version.txt", "w") or die("Unable to open file!");
          fclose($myfile);
        }
          $dist = $foldersname."/node_modules/".$director_; 
          recursiveScan($dist,$listfolders, $listfiles, $foldersname); 
            
              // checking for fonts inside dist
             $dist_fonts = $dist."/fonts";
            $dist_scss = $foldersname."/node_modules/".$director_."/scss";
            $dist_less = $foldersname."/node_modules/".$director_."/less";
            $dist_img = $foldersname."/node_modules/".$director_."/images";
              
              $forward_path_dir = "../../$foldersname/fonts";
              if(file_exists($dist_fonts)) {
                custom_copy($dist_fonts, $forward_path_dir);
              }
              
              // copy scss folder if exists
              $forward_path_scss = "../../$foldersname/scss";
              if(file_exists($dist_scss)) {
                if(!file_exists($forward_path_scss)){
                  mkdir($forward_path_scss, 0777, true); 
                  custom_copy($dist_scss, $forward_path_scss);
                }
              }
              // copy less folder if exists
              
              
              $forward_path_less = "../../$foldersname/less";
              if(file_exists($dist_less)) {
                if(!file_exists($forward_path_less)){
                  mkdir($forward_path_less, 0777, true); 
                  custom_copy($dist_less, $forward_path_less);
                }
              }
              // copy img folder if exists
              
              $forward_path_images = "../../$foldersname/img";
              if(file_exists($dist_img)) {
                if(!file_exists($forward_path_images)){
                  mkdir($forward_path_images, 0777, true); 
                  custom_copy($dist_img, $forward_path_images);
                } else {
                  custom_copy($dist_img, $forward_path_images);
                }
              }
        
              // copy img folder if exists
              $dist_img2 = $foldersname."/node_modules/".$director_."/img";
              
              $forward_path_images2 = "../../$foldersname/img";
              if(file_exists($dist_img2)) {
                if(!file_exists($forward_path_images2)){
                  mkdir($forward_path_images2, 0777, true); 
                  custom_copy($dist_img2, $forward_path_images2);
                } else {
                  custom_copy($dist_img2, $forward_path_images2);
                }
              }
            
            // additional directory
          if(isset($additional_dir)) {
            $dist_source = $foldersname."/node_modules/".$director_."/$additional_dir";
          
            if($additional_dir == "cjs"){
              $scan_addDir = scandir($dist_source);
              foreach($scan_addDir as $scan_addFile) {
                if($scan_addFile != "." && $scan_addFile != "..") {
                if(file_exists("../../$foldersname/cjs_$scan_addFile")){
                  unlink("../../$foldersname/cjs_$scan_addFile");
                  copy("$dist_source/$scan_addFile","../../$foldersname/cjs_$scan_addFile");
                } else {
                  copy("$dist_source/$scan_addFile","../../$foldersname/cjs_$scan_addFile");
                }
                }
              }
            } else {            
            
            if(file_exists($dist_source)) {
              $forward_path_source = "../../$foldersname/$additional_dir";
            
              if(!file_exists($forward_path_source)){
                mkdir($forward_path_source, 0777, true); 
                custom_copy($dist_source, $forward_path_source);
              }
            }
          }
          }
          }

      // Creating Zips
      foreach($get_v_ar as $key => $version) {
        $version = preg_replace('/\s+/', '', $version);
        
          $foldersname = $director;
        
          if(file_exists("../../$foldersname/")){
          $zip_to_create = "../../zip/$foldersname.zip";
          
          
          if(isset($zip_remake)) {
            if(file_exists($zip_to_create)) {
              unlink($zip_to_create);
            }
          }
            
          if(!file_exists($zip_to_create)){

          $rootPath = realpath("../../$foldersname/");

          // Initialize archive object
          $zip = new ZipArchive();
          $zip->open("$zip_to_create", ZipArchive::CREATE | ZipArchive::OVERWRITE);

          $files = new RecursiveIteratorIterator(
              new RecursiveDirectoryIterator($rootPath),
              RecursiveIteratorIterator::LEAVES_ONLY
          );

          foreach ($files as $name => $file)
          {
              if (!$file->isDir())
              {
                 $filePath = $file->getRealPath();
                  $relativePath = substr($filePath, strlen($rootPath) + 1);

                    $zip->addFile($filePath, $relativePath);

              }
          }
          $zip->close();
          }
        }
      }

      // creating index files
      foreach($get_v_ar as $key => $version) {
        $version = preg_replace('/\s+/', '', $version);
         $foldersname = $director;
          
         $index_file = $keyfiles[0];
         $jsext_i = ".js";
        $cssext_i = ".css";
        if(strpos($index_file, $jsext_i) !== false){
          $ext_look = $jsext_i;
          if(file_exists("../../$foldersname/$index_file")) {
            if(file_exists("../../$foldersname/index$ext_look")){
              unlink("../../$foldersname/index$ext_look");
              copy("../../$foldersname/$index_file","../../$foldersname/index$ext_look");
            } else {
              copy("../../$foldersname/$index_file","../../$foldersname/index$ext_look");
            }
          }
          else {
            if(isset($listfiles[1])) {
              $index_file2 = $listfiles[1];
              if(file_exists("../../$foldersname/$index_file2")) {
                
              
              if(file_exists("../../$foldersname/index$ext_look")){
                unlink("../../$foldersname/index$ext_look");
                copy("../../$foldersname/$index_file2","../../$foldersname/index$ext_look");
              } else {
                copy("../../$foldersname/$index_file2","../../$foldersname/index$ext_look");
              }
              }
            }
          }
        } 
        
        
        if(strpos($index_file, $cssext_i) !== false) {
          $ext_look = $cssext_i;
          if(file_exists("../../$foldersname/$index_file")) {
          if(file_exists("../../$foldersname/index$ext_look")){
            unlink("../../$foldersname/index$ext_look");
            copy("../../$foldersname/$index_file","../../$foldersname/index$ext_look");
          } else {
            copy("../../$foldersname/$index_file","../../$foldersname/index$ext_look");
          }
        }
        else {
          if(isset($listfiles[1])) {
            $index_file2 = $listfiles[1];
            if(file_exists("../../$foldersname/$index_file2")) {
            if(file_exists("../../$foldersname/index$ext_look")){
              unlink("../../$foldersname/index$ext_look");
              copy("../../$foldersname/$index_file2","../../$foldersname/index$ext_look");
            } else {
              copy("../../$foldersname/$index_file2","../../$foldersname/index$ext_look");
            }
            }
          }
        }
        }
  
      }
      // creating template files
      foreach($get_v_ar as $key => $version) {
        $version = preg_replace('/\s+/', '', $version);
        $foldersname = $director;  
        
        $mainarticle = "../../cdn/$foldersname";
        $mainfolder = "../../$foldersname";
        
        if(file_exists("../../cdn/$foldersname/var.php")) {
          unlink("../../cdn/$foldersname/var.php");
          copy("var.php","../../cdn/$foldersname/var.php");  
        } else {
          copy("var.php","../../cdn/$foldersname/var.php"); 
        }
        if(!isset($version_lock)) {
        if(file_exists("$mainarticle/index.php")) {
          unlink("$mainarticle/index.php");
          copy("../main-template.php","$mainarticle/index.php");
          
        } else {
          copy("../main-template.php","$mainarticle/index.php");
          
          
        }
        }
        
        // latest version files
        /*
        if($version == $latest_version) {
          if(isset($latest_version_dir)) {
            $dist_source = $foldersname."/node_modules/".$director_."/$latest_version_dir";
            $forward_path_source = "../../$foldersname/$latest_version_dir";
            if(file_exists($dist_source)) {
              if(!file_exists($forward_path_source)){
                mkdir($forward_path_source, 0777, true); 
                custom_copy($dist_source, $forward_path_source);
              }
            }
          }
        
          if(file_exists("../../$director")){
            delete_directory("../../$director");
            custom_copy("../../$foldersname", "../../$director");
          } else {
            custom_copy("../../$foldersname", "../../$director");
          }
          
          if(file_exists("../../cdn/$director")){
            delete_directory("../../cdn/$director");
            custom_copy("../../cdn/$foldersname", "../../cdn/$director");
          } else {
            custom_copy("../../cdn/$foldersname", "../../cdn/$director");
          }
          
            
          if(file_exists("../../zip/$director.zip")){
            unlink("../../zip/$director.zip");
            copy("../../zip/$foldersname.zip","../../zip/$director.zip");
          } else {
            copy("../../zip/$foldersname.zip","../../zip/$director.zip");
          }
        } 
      }*/

      // creating template files for all versions
      /*foreach($get_v_ar_full as $key => $version) {
        $version = preg_replace('/\s+/', '', $version);
        $foldersname = $director."@".$version;  
        
        $mainarticle = "../../cdn/$foldersname";
        $mainfolder = "../../$foldersname";
        
        
        
        if(!isset($version_lock)) {
          
        if(file_exists($mainarticle)) {
           delete_directory($mainarticle);
          mkdir($mainarticle, 0777, true);
        } else {
          mkdir($mainarticle, 0777, true);
        }
        if(file_exists("$mainarticle/index.php")) {
          unlink("$mainarticle/index.php");
          copy("../main-template_clash.php","$mainarticle/index.php");
        } else {      
          copy("../main-template_clash.php","$mainarticle/index.php");
        }
        }
      }
      

    // creating latest version folder
    /*  foreach($get_v_ar as $key => $version) {
        $version = preg_replace('/\s+/', '', $version);
        $foldersname = $director;  
        
        $mainarticle = "../../cdn/$foldersname";
        $mainfolder = "../../$foldersname";
        
        if(file_exists("../../cdn/$director@$latest_version/var.php")) {
          unlink("../../cdn/$director@$latest_version/var.php");
        }
      } */
  ?>
