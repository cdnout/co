<?php 
$npm_check = "@schoolreg/angular-growl-v2";
$keyfiles_add = array("angular-growl.min.css");
$version_limit = "-10";
$type_s = "angular";
?>
