<?php 
$npm_check = "angular-i18n";
$keyfiles_add = array("");
$version_limit = "-10";
$type_s = "jquery";
?>
