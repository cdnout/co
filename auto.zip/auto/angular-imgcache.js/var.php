<?php 
$npm_check = "ng-imgcache@1.0.0";
$keyfiles_add = array("");
$version_limit = "-10";
$type_s = "jquery";
?>
