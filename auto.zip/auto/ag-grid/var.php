<?php 
$npm_check = "ag-grid-community";
$keyfiles_add = array("styles/ag-grid.min.css", "styles/ag-grid.css", "ag-grid.min.js");
$version_limit = "-4";
$type_s = "jquery";
?>
