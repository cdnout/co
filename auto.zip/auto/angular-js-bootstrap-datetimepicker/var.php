<?php 
$npm_check = "angularjs-bootstrap-datetimepicker";
$keyfiles_add = array("datetimepicker.min.css");
$version_limit = "-10";
$type_s = "jquery";
?>
