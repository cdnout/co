<?php 
$npm_check = "ngx-soundmanager2";
$keyfiles_add = array("");
$version_limit = "-10";
$type_s = "angular";
?>
