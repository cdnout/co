<?php 
$npm_check = "angular-translate-storage-cookie";
$keyfiles_add = array("");
$version_limit = "-10";
$type_s = "angular";
?>
