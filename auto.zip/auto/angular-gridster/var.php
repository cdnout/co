<?php 
$npm_check = "angular-gridster";
$keyfiles_add = array("angular-gridster.min.csss");
$version_limit = "-10";
$type_s = "angular";
?>
