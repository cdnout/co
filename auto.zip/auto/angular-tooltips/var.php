<?php 
//$npm_check = "";
$keyfiles_add = array("angular-tooltips.min.css");
$version_limit = "-10";
$type_s = "angular";
?>
