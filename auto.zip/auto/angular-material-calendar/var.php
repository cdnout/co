<?php 
$npm_check = "angular-material-calendar";
$keyfiles_add = array("angular-material-calendar.min.css");
$version_limit = "-10";
$type_s = "angular";
?>
