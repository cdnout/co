<?php 
$npm_check = "ui-select";
$keyfiles_add = array("select.min.css");
$version_limit = "-10";
$type_s = "angular";
?>
