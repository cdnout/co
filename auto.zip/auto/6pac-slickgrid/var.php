<?php 
//$npm_check = "";
$keyfiles_add = array("slick.grid.min.css");
$version_limit = "-10";
$type_s = "javascript";
$strict_cat = "Spreadsheet";
?>
