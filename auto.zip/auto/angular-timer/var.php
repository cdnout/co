<?php 
$npm_check = "angular-timer";
$keyfiles_add = array("css/angular-timer-bower.min.css");
$version_limit = "-10";
$type_s = "angular";
?>
