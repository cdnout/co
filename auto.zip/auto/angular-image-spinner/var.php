<?php 
$npm_check = "angular-image-spinner";
$keyfiles_add = array("");
$version_limit = "-10";
$type_s = "jquery";
?>
