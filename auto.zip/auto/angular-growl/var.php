<?php 
$npm_check = "angular-growl-notifications";
$keyfiles_add = array("angular-growl.min.css");
$version_limit = "-10";
$type_s = "jquery";
?>
