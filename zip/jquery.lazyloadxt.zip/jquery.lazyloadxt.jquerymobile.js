/*! Lazy Load XT v1.1.0 2016-01-12
 * http://ressio.github.io/lazy-load-xt
 * (C) 2016 RESS.io
 * Licensed under MIT */

(function ($) {
    $.lazyLoadXT.updateEvent += ' collapsibleexpand filterablefilter pagechange panelopen popupafteropen tabsactivate';
})(window.jQuery || window.Zepto || window.$);
