export declare function formatTime(seconds: number): string;
