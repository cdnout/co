/// <reference path="../../../src/assets/imports.d.ts" />
export declare const controlsTemplate: HTMLTemplateElement;
export declare const visualizerTemplate: HTMLTemplateElement;
