export declare function normalizePath(path: string): string;
export declare function normalizeSegment(segment: string): string;
export declare function encodePathSegment(str: string): string;
