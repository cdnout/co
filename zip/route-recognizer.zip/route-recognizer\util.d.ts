export declare function createMap<T>(): {
    [key: string]: T | undefined;
};
