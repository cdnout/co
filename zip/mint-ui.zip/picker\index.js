module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.l = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };

/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};

/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};

/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 228);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ function(module, exports) {

/* globals __VUE_SSR_CONTEXT__ */

// this module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier /* server only */
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = injectStyles
  }

  if (hook) {
    var functional = options.functional
    var existing = functional
      ? options.render
      : options.beforeCreate
    if (!functional) {
      // inject component registration as beforeCreate hook
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    } else {
      // register for functioal component in vue file
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return existing(h, context)
      }
    }
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ },

/***/ 1:
/***/ function(module, exports) {

module.exports = require("vue");

/***/ },

/***/ 129:
/***/ function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ },

/***/ 146:
/***/ function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(96)
}
var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(68),
  /* template */
  __webpack_require__(165),
  /* styles */
  injectStyle,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ },

/***/ 147:
/***/ function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(129)
}
var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(69),
  /* template */
  __webpack_require__(199),
  /* styles */
  injectStyle,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ },

/***/ 165:
/***/ function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "picker-slot",
    class: _vm.classNames,
    style: (_vm.flexStyle)
  }, [(!_vm.divider) ? _c('div', {
    ref: "wrapper",
    staticClass: "picker-slot-wrapper",
    class: {
      dragging: _vm.dragging
    },
    style: ({
      height: _vm.contentHeight + 'px'
    })
  }, _vm._l((_vm.mutatingValues), function(itemValue) {
    return _c('div', {
      staticClass: "picker-item",
      class: {
        'picker-selected': itemValue === _vm.currentValue
      },
      style: ({
        height: _vm.itemHeight + 'px',
        lineHeight: _vm.itemHeight + 'px'
      })
    }, [_vm._v("\n      " + _vm._s(typeof itemValue === 'object' && itemValue[_vm.valueKey] ? itemValue[_vm.valueKey] : itemValue) + "\n    ")])
  })) : _vm._e(), _vm._v(" "), (_vm.divider) ? _c('div', [_vm._v(_vm._s(_vm.content))]) : _vm._e()])
},staticRenderFns: []}

/***/ },

/***/ 199:
/***/ function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "picker",
    class: {
      'picker-3d': _vm.rotateEffect
    }
  }, [(_vm.showToolbar) ? _c('div', {
    staticClass: "picker-toolbar"
  }, [_vm._t("default")], 2) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "picker-items"
  }, [_vm._l((_vm.slots), function(slot) {
    return _c('picker-slot', {
      attrs: {
        "valueKey": _vm.valueKey,
        "values": slot.values || [],
        "text-align": slot.textAlign || 'center',
        "visible-item-count": _vm.visibleItemCount,
        "class-name": slot.className,
        "flex": slot.flex,
        "rotate-effect": _vm.rotateEffect,
        "divider": slot.divider,
        "content": slot.content,
        "itemHeight": _vm.itemHeight,
        "default-index": slot.defaultIndex
      },
      model: {
        value: (_vm.values[slot.valueIndex]),
        callback: function($$v) {
          var $$exp = _vm.values,
            $$idx = slot.valueIndex;
          if (!Array.isArray($$exp)) {
            _vm.values[slot.valueIndex] = $$v
          } else {
            $$exp.splice($$idx, 1, $$v)
          }
        },
        expression: "values[slot.valueIndex]"
      }
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "picker-center-highlight",
    style: ({
      height: _vm.itemHeight + 'px',
      marginTop: -_vm.itemHeight / 2 + 'px'
    })
  })], 2)])
},staticRenderFns: []}

/***/ },

/***/ 2:
/***/ function(module, exports, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* unused harmony export on */
/* unused harmony export off */
/* harmony export (binding) */ __webpack_require__.d(exports, "c", function() { return once; });
/* unused harmony export hasClass */
/* harmony export (immutable) */ exports["a"] = addClass;
/* harmony export (immutable) */ exports["b"] = removeClass;
/* unused harmony export getStyle */
/* unused harmony export setStyle */
/* istanbul ignore next */



var isServer = __WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.$isServer;
var SPECIAL_CHARS_REGEXP = /([\:\-\_]+(.))/g;
var MOZ_HACK_REGEXP = /^moz([A-Z])/;
var ieVersion = isServer ? 0 : Number(document.documentMode);

/* istanbul ignore next */
var trim = function(string) {
  return (string || '').replace(/^[\s\uFEFF]+|[\s\uFEFF]+$/g, '');
};
/* istanbul ignore next */
var camelCase = function(name) {
  return name.replace(SPECIAL_CHARS_REGEXP, function(_, separator, letter, offset) {
    return offset ? letter.toUpperCase() : letter;
  }).replace(MOZ_HACK_REGEXP, 'Moz$1');
};

/* istanbul ignore next */
var on = (function() {
  if (!isServer && document.addEventListener) {
    return function(element, event, handler) {
      if (element && event && handler) {
        element.addEventListener(event, handler, false);
      }
    };
  } else {
    return function(element, event, handler) {
      if (element && event && handler) {
        element.attachEvent('on' + event, handler);
      }
    };
  }
})();

/* istanbul ignore next */
var off = (function() {
  if (!isServer && document.removeEventListener) {
    return function(element, event, handler) {
      if (element && event) {
        element.removeEventListener(event, handler, false);
      }
    };
  } else {
    return function(element, event, handler) {
      if (element && event) {
        element.detachEvent('on' + event, handler);
      }
    };
  }
})();

/* istanbul ignore next */
var once = function(el, event, fn) {
  var listener = function() {
    if (fn) {
      fn.apply(this, arguments);
    }
    off(el, event, listener);
  };
  on(el, event, listener);
};

/* istanbul ignore next */
function hasClass(el, cls) {
  if (!el || !cls) return false;
  if (cls.indexOf(' ') !== -1) throw new Error('className should not contain space.');
  if (el.classList) {
    return el.classList.contains(cls);
  } else {
    return (' ' + el.className + ' ').indexOf(' ' + cls + ' ') > -1;
  }
};

/* istanbul ignore next */
function addClass(el, cls) {
  if (!el) return;
  var curClass = el.className;
  var classes = (cls || '').split(' ');

  for (var i = 0, j = classes.length; i < j; i++) {
    var clsName = classes[i];
    if (!clsName) continue;

    if (el.classList) {
      el.classList.add(clsName);
    } else {
      if (!hasClass(el, clsName)) {
        curClass += ' ' + clsName;
      }
    }
  }
  if (!el.classList) {
    el.className = curClass;
  }
};

/* istanbul ignore next */
function removeClass(el, cls) {
  if (!el || !cls) return;
  var classes = cls.split(' ');
  var curClass = ' ' + el.className + ' ';

  for (var i = 0, j = classes.length; i < j; i++) {
    var clsName = classes[i];
    if (!clsName) continue;

    if (el.classList) {
      el.classList.remove(clsName);
    } else {
      if (hasClass(el, clsName)) {
        curClass = curClass.replace(' ' + clsName + ' ', ' ');
      }
    }
  }
  if (!el.classList) {
    el.className = trim(curClass);
  }
};

/* istanbul ignore next */
var getStyle = ieVersion < 9 ? function(element, styleName) {
  if (isServer) return;
  if (!element || !styleName) return null;
  styleName = camelCase(styleName);
  if (styleName === 'float') {
    styleName = 'styleFloat';
  }
  try {
    switch (styleName) {
      case 'opacity':
        try {
          return element.filters.item('alpha').opacity / 100;
        } catch (e) {
          return 1.0;
        }
      default:
        return (element.style[styleName] || element.currentStyle ? element.currentStyle[styleName] : null);
    }
  } catch (e) {
    return element.style[styleName];
  }
} : function(element, styleName) {
  if (isServer) return;
  if (!element || !styleName) return null;
  styleName = camelCase(styleName);
  if (styleName === 'float') {
    styleName = 'cssFloat';
  }
  try {
    var computed = document.defaultView.getComputedStyle(element, '');
    return element.style[styleName] || computed ? computed[styleName] : null;
  } catch (e) {
    return element.style[styleName];
  }
};

/* istanbul ignore next */
function setStyle(element, styleName, value) {
  if (!element || !styleName) return;

  if (typeof styleName === 'object') {
    for (var prop in styleName) {
      if (styleName.hasOwnProperty(prop)) {
        setStyle(element, prop, styleName[prop]);
      }
    }
  } else {
    styleName = camelCase(styleName);
    if (styleName === 'opacity' && ieVersion < 9) {
      element.style.filter = isNaN(value) ? '' : 'alpha(opacity=' + value * 100 + ')';
    } else {
      element.style[styleName] = value;
    }
  }
};


/***/ },

/***/ 207:
/***/ function(module, exports) {

module.exports = require("raf.js");

/***/ },

/***/ 228:
/***/ function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(36);


/***/ },

/***/ 36:
/***/ function(module, exports, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_picker_vue__ = __webpack_require__(147);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_picker_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__src_picker_vue__);
Object.defineProperty(exports, "__esModule", { value: true });
/* harmony reexport (default from non-hamory) */ __webpack_require__.d(exports, "default", function() { return __WEBPACK_IMPORTED_MODULE_0__src_picker_vue___default.a; });



/***/ },

/***/ 68:
/***/ function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__draggable__ = __webpack_require__(91);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__translate__ = __webpack_require__(92);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mint_ui_src_utils_dom__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_mint_ui_src_mixins_emitter__ = __webpack_require__(95);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_vue__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






if (!__WEBPACK_IMPORTED_MODULE_4_vue___default.a.prototype.$isServer) {
  __webpack_require__(207);
}

var rotateElement = function(element, angle) {
  if (!element) return;
  var transformProperty = __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].transformProperty;

  element.style[transformProperty] = element.style[transformProperty].replace(/rotateX\(.+?deg\)/gi, '') + " rotateX(" + angle + "deg)";
};

var ITEM_HEIGHT = 36;
var VISIBLE_ITEMS_ANGLE_MAP = {
  3: -45,
  5: -20,
  7: -15
};

/* harmony default export */ exports["default"] = {
  name: 'picker-slot',

  props: {
    values: {
      type: Array,
      default: function default$1() {
        return [];
      }
    },
    value: {},
    visibleItemCount: {
      type: Number,
      default: 5
    },
    valueKey: String,
    rotateEffect: {
      type: Boolean,
      default: false
    },
    divider: {
      type: Boolean,
      default: false
    },
    textAlign: {
      type: String,
      default: 'center'
    },
    flex: {},
    className: {},
    content: {},
    itemHeight: {
      type: Number,
      default: ITEM_HEIGHT
    },
    defaultIndex: {
      type: Number,
      default: 0,
      require: false
    }
  },

  data: function data() {
    return {
      currentValue: this.value,
      mutatingValues: this.values,
      dragging: false,
      animationFrameId: null
    };
  },

  mixins: [__WEBPACK_IMPORTED_MODULE_3_mint_ui_src_mixins_emitter__["a" /* default */]],

  computed: {
    flexStyle: function flexStyle() {
      return {
        'flex': this.flex,
        '-webkit-box-flex': this.flex,
        '-moz-box-flex': this.flex,
        '-ms-flex': this.flex
      };
    },
    classNames: function classNames() {
      var PREFIX = 'picker-slot-';
      var resultArray = [];

      if (this.rotateEffect) {
        resultArray.push(PREFIX + 'absolute');
      }

      var textAlign = this.textAlign || 'center';
      resultArray.push(PREFIX + textAlign);

      if (this.divider) {
        resultArray.push(PREFIX + 'divider');
      }

      if (this.className) {
        resultArray.push(this.className);
      }

      return resultArray.join(' ');
    },
    contentHeight: function contentHeight() {
      return this.itemHeight * this.visibleItemCount;
    },
    valueIndex: function valueIndex() {
      var this$1 = this;

      var valueKey = this.valueKey;
      if (this.currentValue instanceof Object) {
        for (var i = 0, len = this.mutatingValues.length; i < len ; i++) {
          if (this$1.currentValue[valueKey] === this$1.mutatingValues[i][valueKey]) {
            return i;
          }
        }
        return -1;
      } else {
        return this.mutatingValues.indexOf(this.currentValue);
      }
    },
    dragRange: function dragRange() {
      var values = this.mutatingValues;
      var visibleItemCount = this.visibleItemCount;
      var itemHeight = this.itemHeight;

      return [ -itemHeight * (values.length - Math.ceil(visibleItemCount / 2)), itemHeight * Math.floor(visibleItemCount / 2) ];
    },
    minTranslateY: function minTranslateY() {
      return this.itemHeight * (Math.ceil(this.visibleItemCount / 2) - this.mutatingValues.length);
    },
    maxTranslateY: function maxTranslateY() {
      return this.itemHeight * Math.floor(this.visibleItemCount / 2);
    }
  },

  methods: {
    value2Translate: function value2Translate(value) {
      var values = this.mutatingValues;
      var valueIndex = values.indexOf(value);
      var offset = Math.floor(this.visibleItemCount / 2);
      var itemHeight = this.itemHeight;

      if (valueIndex !== -1) {
        return (valueIndex - offset) * -itemHeight;
      }
    },

    translate2Value: function translate2Value(translate) {
      var itemHeight = this.itemHeight;
      translate = Math.round(translate / itemHeight) * itemHeight;
      var index = -(translate - Math.floor(this.visibleItemCount / 2) * itemHeight) / itemHeight;

      return this.mutatingValues[index];
    },

    updateRotate: function(currentTranslate, pickerItems) {
      var this$1 = this;

      if (this.divider) return;
      var dragRange = this.dragRange;
      var wrapper = this.$refs.wrapper;

      if (!pickerItems) {
        pickerItems = wrapper.querySelectorAll('.picker-item');
      }

      if (currentTranslate === undefined) {
        currentTranslate = __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].getElementTranslate(wrapper).top;
      }

      var itemsFit = Math.ceil(this.visibleItemCount / 2);
      var angleUnit = VISIBLE_ITEMS_ANGLE_MAP[this.visibleItemCount] || -20;

      [].forEach.call(pickerItems, function (item, index) {
        var itemOffsetTop = index * this$1.itemHeight;
        var translateOffset = dragRange[1] - currentTranslate;
        var itemOffset = itemOffsetTop - translateOffset;
        var percentage = itemOffset / this$1.itemHeight;

        var angle = angleUnit * percentage;
        if (angle > 180) angle = 180;
        if (angle < -180) angle = -180;

        rotateElement(item, angle);

        if (Math.abs(percentage) > itemsFit) {
          __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_2_mint_ui_src_utils_dom__["a" /* addClass */])(item, 'picker-item-far');
        } else {
          __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_2_mint_ui_src_utils_dom__["b" /* removeClass */])(item, 'picker-item-far');
        }
      });
    },

    planUpdateRotate: function() {
      var this$1 = this;

      var el = this.$refs.wrapper;
      cancelAnimationFrame(this.animationFrameId);

      this.animationFrameId = requestAnimationFrame(function () {
        this$1.updateRotate();
      });

      __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_2_mint_ui_src_utils_dom__["c" /* once */])(el, __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].transitionEndProperty, function () {
        cancelAnimationFrame(this$1.animationFrameId);
        this$1.animationFrameId = null;
      });
    },

    initEvents: function initEvents() {
      var this$1 = this;

      var el = this.$refs.wrapper;
      var dragState = {};

      var velocityTranslate, prevTranslate, pickerItems;

      __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__draggable__["a" /* default */])(el, {
        start: function (event) {
          cancelAnimationFrame(this$1.animationFrameId);
          this$1.animationFrameId = null;
          dragState = {
            range: this$1.dragRange,
            start: new Date(),
            startLeft: event.pageX,
            startTop: event.pageY,
            startTranslateTop: __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].getElementTranslate(el).top
          };
          pickerItems = el.querySelectorAll('.picker-item');
        },

        drag: function (event) {
          this$1.dragging = true;

          dragState.left = event.pageX;
          dragState.top = event.pageY;

          var deltaY = dragState.top - dragState.startTop;
          var translate = dragState.startTranslateTop + deltaY;

          __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].translateElement(el, null, translate);

          velocityTranslate = translate - prevTranslate || translate;

          prevTranslate = translate;

          if (this$1.rotateEffect) {
            this$1.updateRotate(prevTranslate, pickerItems);
          }
        },

        end: function (event) {
          this$1.dragging = false;

          var momentumRatio = 7;
          var currentTranslate = __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].getElementTranslate(el).top;
          var duration = new Date() - dragState.start;
          var distance = Math.abs(dragState.startTranslateTop - currentTranslate);
          var itemHeight = this$1.itemHeight;
          var visibleItemCount = this$1.visibleItemCount;

          var rect, offset;
          if (distance < 6) {
            rect = this$1.$el.getBoundingClientRect();
            offset = Math.floor((event.clientY - (rect.top + (visibleItemCount - 1) * itemHeight / 2)) / itemHeight) * itemHeight;

            if (offset > this$1.maxTranslateY) {
              offset = this$1.maxTranslateY;
            }

            velocityTranslate = 0;
            currentTranslate -= offset;
          }

          var momentumTranslate;
          if (duration < 300) {
            momentumTranslate = currentTranslate + velocityTranslate * momentumRatio;
          }

          var dragRange = dragState.range;

          this$1.$nextTick(function () {
            var translate;
            if (momentumTranslate) {
              translate = Math.round(momentumTranslate / itemHeight) * itemHeight;
            } else {
              translate = Math.round(currentTranslate / itemHeight) * itemHeight;
            }

            translate = Math.max(Math.min(translate, dragRange[1]), dragRange[0]);

            __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].translateElement(el, null, translate);

            this$1.currentValue = this$1.translate2Value(translate);

            if (this$1.rotateEffect) {
              this$1.planUpdateRotate();
            }
          });

          dragState = {};
        }
      });
    },

    doOnValueChange: function doOnValueChange() {
      var value = this.currentValue;
      var wrapper = this.$refs.wrapper;

      __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].translateElement(wrapper, null, this.value2Translate(value));
    },

    doOnValuesChange: function doOnValuesChange() {
      var this$1 = this;

      var el = this.$el;
      var items = el.querySelectorAll('.picker-item');
      [].forEach.call(items, function (item, index) {
        __WEBPACK_IMPORTED_MODULE_1__translate__["a" /* default */].translateElement(item, null, this$1.itemHeight * index);
      });
      if (this.rotateEffect) {
        this.planUpdateRotate();
      }
    }
  },

  mounted: function mounted() {
    this.ready = true;

    if (!this.divider) {
      this.initEvents();
      this.doOnValueChange();
    }

    if (this.rotateEffect) {
      this.doOnValuesChange();
    }
  },

  watch: {
    values: function values(val) {
      this.mutatingValues = val;
    },

    mutatingValues: function mutatingValues(val) {
      var this$1 = this;

      if (this.valueIndex === -1) {
        this.currentValue = (val || [])[0];
      }
      if (this.rotateEffect) {
        this.$nextTick(function () {
          this$1.doOnValuesChange();
        });
      }
    },
    currentValue: function currentValue(val) {
      this.doOnValueChange();
      if (this.rotateEffect) {
        this.planUpdateRotate();
      }
      this.$emit('input', val);
      this.dispatch('picker', 'slotValueChange', this);
    },
    defaultIndex: function defaultIndex(val) {
      if ((this.mutatingValues[val] !== undefined) && (this.mutatingValues.length >= val + 1)) {
        this.currentValue = this.mutatingValues[val];
      }
    }
  }
};


/***/ },

/***/ 69:
/***/ function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ exports["default"] = {
  name: 'mt-picker',

  componentName: 'picker',

  props: {
    slots: {
      type: Array
    },
    showToolbar: {
      type: Boolean,
      default: false
    },
    visibleItemCount: {
      type: Number,
      default: 5
    },
    valueKey: String,
    rotateEffect: {
      type: Boolean,
      default: false
    },
    itemHeight: {
      type: Number,
      default: 36
    }
  },

  created: function created() {
    this.$on('slotValueChange', this.slotValueChange);
    this.slotValueChange();
  },

  methods: {
    slotValueChange: function slotValueChange() {
      this.$emit('change', this, this.values);
    },

    getSlot: function getSlot(slotIndex) {
      var slots = this.slots || [];
      var count = 0;
      var target;
      var children = this.$children.filter(function (child) { return child.$options.name === 'picker-slot'; });

      slots.forEach(function(slot, index) {
        if (!slot.divider) {
          if (slotIndex === count) {
            target = children[index];
          }
          count++;
        }
      });

      return target;
    },
    getSlotValue: function getSlotValue(index) {
      var slot = this.getSlot(index);
      if (slot) {
        return slot.currentValue;
      }
      return null;
    },
    setSlotValue: function setSlotValue(index, value) {
      var slot = this.getSlot(index);
      if (slot) {
        slot.currentValue = value;
      }
    },
    getSlotValues: function getSlotValues(index) {
      var slot = this.getSlot(index);
      if (slot) {
        return slot.mutatingValues;
      }
      return null;
    },
    setSlotValues: function setSlotValues(index, values) {
      var slot = this.getSlot(index);
      if (slot) {
        slot.mutatingValues = values;
      }
    },
    getValues: function getValues() {
      return this.values;
    },
    setValues: function setValues(values) {
      var this$1 = this;

      var slotCount = this.slotCount;
      values = values || [];
      if (slotCount !== values.length) {
        throw new Error('values length is not equal slot count.');
      }
      values.forEach(function (value, index) {
        this$1.setSlotValue(index, value);
      });
    }
  },

  computed: {
    values: {
      get: function get() {
        var slots = this.slots || [];
        var values = [];
        var valueIndexCount = 0;
        slots.forEach(function (slot) {
          if (!slot.divider) {
            slot.valueIndex = valueIndexCount++;
            values[slot.valueIndex] = (slot.values || [])[slot.defaultIndex || 0];
          }
        });
        return values;
      }
    },
    slotCount: function slotCount() {
      var slots = this.slots || [];
      var result = 0;
      slots.forEach(function(slot) {
        if (!slot.divider) result++;
      });
      return result;
    }
  },

  components: {
    PickerSlot: __webpack_require__(146)
  }
};


/***/ },

/***/ 91:
/***/ function(module, exports, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
var isDragging = false;


var supportTouch = !__WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.$isServer && 'ontouchstart' in window;

/* harmony default export */ exports["a"] = function(element, options) {
  var moveFn = function(event) {
    if (options.drag) {
      options.drag(supportTouch ? event.changedTouches[0] || event.touches[0] : event);
    }
  };

  var endFn = function(event) {
    if (!supportTouch) {
      document.removeEventListener('mousemove', moveFn);
      document.removeEventListener('mouseup', endFn);
    }
    document.onselectstart = null;
    document.ondragstart = null;

    isDragging = false;

    if (options.end) {
      options.end(supportTouch ? event.changedTouches[0] || event.touches[0] : event);
    }
  };

  element.addEventListener(supportTouch ? 'touchstart' : 'mousedown', function(event) {
    if (isDragging) return;
    document.onselectstart = function() { return false; };
    document.ondragstart = function() { return false; };

    if (!supportTouch) {
      document.addEventListener('mousemove', moveFn);
      document.addEventListener('mouseup', endFn);
    }
    isDragging = true;

    if (options.start) {
      event.preventDefault();
      options.start(supportTouch ? event.changedTouches[0] || event.touches[0] : event);
    }
  });

  if (supportTouch) {
    element.addEventListener('touchmove', moveFn);
    element.addEventListener('touchend', endFn);
    element.addEventListener('touchcancel', endFn);
  }
};;


/***/ },

/***/ 92:
/***/ function(module, exports, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
var exportObj = {};

if (!__WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.$isServer) {
  var docStyle = document.documentElement.style;
  var engine;
  var translate3d = false;

  if (window.opera && Object.prototype.toString.call(opera) === '[object Opera]') {
    engine = 'presto';
  } else if ('MozAppearance' in docStyle) {
    engine = 'gecko';
  } else if ('WebkitAppearance' in docStyle) {
    engine = 'webkit';
  } else if (typeof navigator.cpuClass === 'string') {
    engine = 'trident';
  }

  var cssPrefix = {trident: '-ms-', gecko: '-moz-', webkit: '-webkit-', presto: '-o-'}[engine];

  var vendorPrefix = {trident: 'ms', gecko: 'Moz', webkit: 'Webkit', presto: 'O'}[engine];

  var helperElem = document.createElement('div');
  var perspectiveProperty = vendorPrefix + 'Perspective';
  var transformProperty = vendorPrefix + 'Transform';
  var transformStyleName = cssPrefix + 'transform';
  var transitionProperty = vendorPrefix + 'Transition';
  var transitionStyleName = cssPrefix + 'transition';
  var transitionEndProperty = vendorPrefix.toLowerCase() + 'TransitionEnd';

  if (helperElem.style[perspectiveProperty] !== undefined) {
    translate3d = true;
  }

  var getTranslate = function(element) {
    var result = {left: 0, top: 0};
    if (element === null || element.style === null) return result;

    var transform = element.style[transformProperty];
    var matches = /translate\(\s*(-?\d+(\.?\d+?)?)px,\s*(-?\d+(\.\d+)?)px\)\s*translateZ\(0px\)/ig.exec(transform);
    if (matches) {
      result.left = +matches[1];
      result.top = +matches[3];
    }

    return result;
  };

  var translateElement = function(element, x, y) {
    if (x === null && y === null) return;

    if (element === null || element === undefined || element.style === null) return;

    if (!element.style[transformProperty] && x === 0 && y === 0) return;

    if (x === null || y === null) {
      var translate = getTranslate(element);
      if (x === null) {
        x = translate.left;
      }
      if (y === null) {
        y = translate.top;
      }
    }

    cancelTranslateElement(element);

    if (translate3d) {
      element.style[transformProperty] += ' translate(' + (x ? (x + 'px') : '0px') + ',' + (y ? (y + 'px') : '0px') + ') translateZ(0px)';
    } else {
      element.style[transformProperty] += ' translate(' + (x ? (x + 'px') : '0px') + ',' + (y ? (y + 'px') : '0px') + ')';
    }
  };

  var cancelTranslateElement = function(element) {
    if (element === null || element.style === null) return;
    var transformValue = element.style[transformProperty];
    if (transformValue) {
      transformValue = transformValue.replace(/translate\(\s*(-?\d+(\.?\d+?)?)px,\s*(-?\d+(\.\d+)?)px\)\s*translateZ\(0px\)/g, '');
      element.style[transformProperty] = transformValue;
    }
  };
  exportObj = {
    transformProperty: transformProperty,
    transformStyleName: transformStyleName,
    transitionProperty: transitionProperty,
    transitionStyleName: transitionStyleName,
    transitionEndProperty: transitionEndProperty,
    getElementTranslate: getTranslate,
    translateElement: translateElement,
    cancelTranslateElement: cancelTranslateElement
  };
};

/* harmony default export */ exports["a"] = exportObj;


/***/ },

/***/ 95:
/***/ function(module, exports, __webpack_require__) {

"use strict";
function broadcast(componentName, eventName, params) {
  this.$children.forEach(function (child) {
    var name = child.$options.componentName;

    if (name === componentName) {
      child.$emit.apply(child, [eventName].concat(params));
    } else {
      broadcast.apply(child, [componentName, eventName].concat(params));
    }
  });
}
/* harmony default export */ exports["a"] = {
  methods: {
    dispatch: function dispatch(componentName, eventName, params) {
      var parent = this.$parent;
      var name = parent.$options.componentName;

      while (parent && (!name || name !== componentName)) {
        parent = parent.$parent;

        if (parent) {
          name = parent.$options.componentName;
        }
      }
      if (parent) {
        parent.$emit.apply(parent, [eventName].concat(params));
      }
    },
    broadcast: function broadcast$1(componentName, eventName, params) {
      broadcast.call(this, componentName, eventName, params);
    }
  }
};


/***/ },

/***/ 96:
/***/ function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }

/******/ });