module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.l = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };

/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};

/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};

/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 224);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ function(module, exports) {

/* globals __VUE_SSR_CONTEXT__ */

// this module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier /* server only */
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = injectStyles
  }

  if (hook) {
    var functional = options.functional
    var existing = functional
      ? options.render
      : options.beforeCreate
    if (!functional) {
      // inject component registration as beforeCreate hook
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    } else {
      // register for functioal component in vue file
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return existing(h, context)
      }
    }
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ },

/***/ 10:
/***/ function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

/* harmony default export */ exports["default"] = {
  computed: {
    spinnerColor: function spinnerColor() {
      return this.color || this.$parent.color || '#ccc';
    },

    spinnerSize: function spinnerSize() {
      return (this.size || this.$parent.size || 28) + 'px';
    }
  },

  props: {
    size: Number,
    color: String
  }
};


/***/ },

/***/ 11:
/***/ function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__common_vue__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__common_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__common_vue__);
//
//
//
//
//
//
//
//
//



/* harmony default export */ exports["default"] = {
  name: 'fading-circle',

  mixins: [__WEBPACK_IMPORTED_MODULE_0__common_vue___default.a],

  created: function created() {
    if (this.$isServer) return;
    this.styleNode = document.createElement('style');
    var css = ".circle-color-" + (this._uid) + " > div::before { background-color: " + (this.spinnerColor) + "; }";

    this.styleNode.type = 'text/css';
    this.styleNode.rel = 'stylesheet';
    this.styleNode.title = 'fading circle style';
    document.getElementsByTagName('head')[0].appendChild(this.styleNode);
    this.styleNode.appendChild(document.createTextNode(css));
  },

  destroyed: function destroyed() {
    if (this.styleNode) {
      this.styleNode.parentNode.removeChild(this.styleNode);
    }
  }
};


/***/ },

/***/ 124:
/***/ function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ },

/***/ 14:
/***/ function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ },

/***/ 142:
/***/ function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(124)
}
var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(64),
  /* template */
  __webpack_require__(194),
  /* styles */
  injectStyle,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ },

/***/ 15:
/***/ function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(14)
}
var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(11),
  /* template */
  __webpack_require__(16),
  /* styles */
  injectStyle,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ },

/***/ 16:
/***/ function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: ['mint-spinner-fading-circle circle-color-' + _vm._uid],
    style: ({
      width: _vm.spinnerSize,
      height: _vm.spinnerSize
    })
  }, _vm._l((12), function(n) {
    return _c('div', {
      staticClass: "mint-spinner-fading-circle-circle",
      class: ['is-circle' + (n + 1)]
    })
  }))
},staticRenderFns: []}

/***/ },

/***/ 194:
/***/ function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "mint-loadmore"
  }, [_c('div', {
    staticClass: "mint-loadmore-content",
    class: {
      'is-dropped': _vm.topDropped || _vm.bottomDropped
    },
    style: ({
      'transform': _vm.transform
    })
  }, [_vm._t("top", [(_vm.topMethod) ? _c('div', {
    staticClass: "mint-loadmore-top"
  }, [(_vm.topStatus === 'loading') ? _c('spinner', {
    staticClass: "mint-loadmore-spinner",
    attrs: {
      "size": 20,
      "type": "fading-circle"
    }
  }) : _vm._e(), _vm._v(" "), _c('span', {
    staticClass: "mint-loadmore-text"
  }, [_vm._v(_vm._s(_vm.topText))])], 1) : _vm._e()]), _vm._v(" "), _vm._t("default"), _vm._v(" "), _vm._t("bottom", [(_vm.bottomMethod) ? _c('div', {
    staticClass: "mint-loadmore-bottom"
  }, [(_vm.bottomStatus === 'loading') ? _c('spinner', {
    staticClass: "mint-loadmore-spinner",
    attrs: {
      "size": 20,
      "type": "fading-circle"
    }
  }) : _vm._e(), _vm._v(" "), _c('span', {
    staticClass: "mint-loadmore-text"
  }, [_vm._v(_vm._s(_vm.bottomText))])], 1) : _vm._e()])], 2)])
},staticRenderFns: []}

/***/ },

/***/ 224:
/***/ function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(32);


/***/ },

/***/ 32:
/***/ function(module, exports, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_loadmore_vue__ = __webpack_require__(142);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_loadmore_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__src_loadmore_vue__);
Object.defineProperty(exports, "__esModule", { value: true });
/* harmony reexport (default from non-hamory) */ __webpack_require__.d(exports, "default", function() { return __WEBPACK_IMPORTED_MODULE_0__src_loadmore_vue___default.a; });



/***/ },

/***/ 6:
/***/ function(module, exports, __webpack_require__) {

var Component = __webpack_require__(0)(
  /* script */
  __webpack_require__(10),
  /* template */
  null,
  /* styles */
  null,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ },

/***/ 64:
/***/ function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_mint_ui_packages_spinner_src_spinner_fading_circle_vue__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_mint_ui_packages_spinner_src_spinner_fading_circle_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_mint_ui_packages_spinner_src_spinner_fading_circle_vue__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ exports["default"] = {
  name: 'mt-loadmore',
  components: {
    'spinner': __WEBPACK_IMPORTED_MODULE_0_mint_ui_packages_spinner_src_spinner_fading_circle_vue___default.a
  },

  props: {
    maxDistance: {
      type: Number,
      default: 0
    },
    autoFill: {
      type: Boolean,
      default: true
    },
    distanceIndex: {
      type: Number,
      default: 2
    },
    topPullText: {
      type: String,
      default: '下拉刷新'
    },
    topDropText: {
      type: String,
      default: '释放更新'
    },
    topLoadingText: {
      type: String,
      default: '加载中...'
    },
    topDistance: {
      type: Number,
      default: 70
    },
    topMethod: {
      type: Function
    },
    bottomPullText: {
      type: String,
      default: '上拉刷新'
    },
    bottomDropText: {
      type: String,
      default: '释放更新'
    },
    bottomLoadingText: {
      type: String,
      default: '加载中...'
    },
    bottomDistance: {
      type: Number,
      default: 70
    },
    bottomMethod: {
      type: Function
    },
    bottomAllLoaded: {
      type: Boolean,
      default: false
    }
  },

  data: function data() {
    return {
      translate: 0,
      scrollEventTarget: null,
      containerFilled: false,
      topText: '',
      topDropped: false,
      bottomText: '',
      bottomDropped: false,
      bottomReached: false,
      direction: '',
      startY: 0,
      startScrollTop: 0,
      currentY: 0,
      topStatus: '',
      bottomStatus: ''
    };
  },

  computed: {
    transform: function transform() {
      return this.translate === 0 ? null : 'translate3d(0, ' + this.translate + 'px, 0)';
    }
  },

  watch: {
    topStatus: function topStatus(val) {
      this.$emit('top-status-change', val);
      switch (val) {
        case 'pull':
          this.topText = this.topPullText;
          break;
        case 'drop':
          this.topText = this.topDropText;
          break;
        case 'loading':
          this.topText = this.topLoadingText;
          break;
      }
    },

    bottomStatus: function bottomStatus(val) {
      this.$emit('bottom-status-change', val);
      switch (val) {
        case 'pull':
          this.bottomText = this.bottomPullText;
          break;
        case 'drop':
          this.bottomText = this.bottomDropText;
          break;
        case 'loading':
          this.bottomText = this.bottomLoadingText;
          break;
      }
    }
  },

  methods: {
    onTopLoaded: function onTopLoaded() {
      var this$1 = this;

      this.translate = 0;
      setTimeout(function () {
        this$1.topStatus = 'pull';
      }, 200);
    },

    onBottomLoaded: function onBottomLoaded() {
      var this$1 = this;

      this.bottomStatus = 'pull';
      this.bottomDropped = false;
      this.$nextTick(function () {
        if (this$1.scrollEventTarget === window) {
          document.body.scrollTop += 50;
        } else {
          this$1.scrollEventTarget.scrollTop += 50;
        }
        this$1.translate = 0;
      });
      if (!this.bottomAllLoaded && !this.containerFilled) {
        this.fillContainer();
      }
    },

    getScrollEventTarget: function getScrollEventTarget(element) {
      var currentNode = element;
      while (currentNode && currentNode.tagName !== 'HTML' &&
        currentNode.tagName !== 'BODY' && currentNode.nodeType === 1) {
        var overflowY = document.defaultView.getComputedStyle(currentNode).overflowY;
        if (overflowY === 'scroll' || overflowY === 'auto') {
          return currentNode;
        }
        currentNode = currentNode.parentNode;
      }
      return window;
    },

    getScrollTop: function getScrollTop(element) {
      if (element === window) {
        return Math.max(window.pageYOffset || 0, document.documentElement.scrollTop);
      } else {
        return element.scrollTop;
      }
    },

    bindTouchEvents: function bindTouchEvents() {
      this.$el.addEventListener('touchstart', this.handleTouchStart);
      this.$el.addEventListener('touchmove', this.handleTouchMove);
      this.$el.addEventListener('touchend', this.handleTouchEnd);
    },

    init: function init() {
      this.topStatus = 'pull';
      this.bottomStatus = 'pull';
      this.topText = this.topPullText;
      this.scrollEventTarget = this.getScrollEventTarget(this.$el);
      if (typeof this.bottomMethod === 'function') {
        this.fillContainer();
        this.bindTouchEvents();
      }
      if (typeof this.topMethod === 'function') {
        this.bindTouchEvents();
      }
    },

    fillContainer: function fillContainer() {
      var this$1 = this;

      if (this.autoFill) {
        this.$nextTick(function () {
          if (this$1.scrollEventTarget === window) {
            this$1.containerFilled = this$1.$el.getBoundingClientRect().bottom >=
              document.documentElement.getBoundingClientRect().bottom;
          } else {
            this$1.containerFilled = this$1.$el.getBoundingClientRect().bottom >=
              this$1.scrollEventTarget.getBoundingClientRect().bottom;
          }
          if (!this$1.containerFilled) {
            this$1.bottomStatus = 'loading';
            this$1.bottomMethod();
          }
        });
      }
    },

    checkBottomReached: function checkBottomReached() {
      if (this.scrollEventTarget === window) {
        return document.body.scrollTop + document.documentElement.clientHeight >= document.body.scrollHeight;
      } else {
        return this.$el.getBoundingClientRect().bottom <= this.scrollEventTarget.getBoundingClientRect().bottom + 1;
      }
    },

    handleTouchStart: function handleTouchStart(event) {
      this.startY = event.touches[0].clientY;
      this.startScrollTop = this.getScrollTop(this.scrollEventTarget);
      this.bottomReached = false;
      if (this.topStatus !== 'loading') {
        this.topStatus = 'pull';
        this.topDropped = false;
      }
      if (this.bottomStatus !== 'loading') {
        this.bottomStatus = 'pull';
        this.bottomDropped = false;
      }
    },

    handleTouchMove: function handleTouchMove(event) {
      if (this.startY < this.$el.getBoundingClientRect().top && this.startY > this.$el.getBoundingClientRect().bottom) {
        return;
      }
      this.currentY = event.touches[0].clientY;
      var distance = (this.currentY - this.startY) / this.distanceIndex;
      this.direction = distance > 0 ? 'down' : 'up';
      if (typeof this.topMethod === 'function' && this.direction === 'down' &&
        this.getScrollTop(this.scrollEventTarget) === 0 && this.topStatus !== 'loading') {
        event.preventDefault();
        event.stopPropagation();
        if (this.maxDistance > 0) {
          this.translate = distance <= this.maxDistance ? distance - this.startScrollTop : this.translate;
        } else {
          this.translate = distance - this.startScrollTop;
        }
        if (this.translate < 0) {
          this.translate = 0;
        }
        this.topStatus = this.translate >= this.topDistance ? 'drop' : 'pull';
      }

      if (this.direction === 'up') {
        this.bottomReached = this.bottomReached || this.checkBottomReached();
      }
      if (typeof this.bottomMethod === 'function' && this.direction === 'up' &&
        this.bottomReached && this.bottomStatus !== 'loading' && !this.bottomAllLoaded) {
        event.preventDefault();
        event.stopPropagation();
        if (this.maxDistance > 0) {
          this.translate = Math.abs(distance) <= this.maxDistance
            ? this.getScrollTop(this.scrollEventTarget) - this.startScrollTop + distance : this.translate;
        } else {
          this.translate = this.getScrollTop(this.scrollEventTarget) - this.startScrollTop + distance;
        }
        if (this.translate > 0) {
          this.translate = 0;
        }
        this.bottomStatus = -this.translate >= this.bottomDistance ? 'drop' : 'pull';
      }
      this.$emit('translate-change', this.translate);
    },

    handleTouchEnd: function handleTouchEnd() {
      if (this.direction === 'down' && this.getScrollTop(this.scrollEventTarget) === 0 && this.translate > 0) {
        this.topDropped = true;
        if (this.topStatus === 'drop') {
          this.translate = '50';
          this.topStatus = 'loading';
          this.topMethod();
        } else {
          this.translate = '0';
          this.topStatus = 'pull';
        }
      }
      if (this.direction === 'up' && this.bottomReached && this.translate < 0) {
        this.bottomDropped = true;
        this.bottomReached = false;
        if (this.bottomStatus === 'drop') {
          this.translate = '-50';
          this.bottomStatus = 'loading';
          this.bottomMethod();
        } else {
          this.translate = '0';
          this.bottomStatus = 'pull';
        }
      }
      this.$emit('translate-change', this.translate);
      this.direction = '';
    }
  },

  mounted: function mounted() {
    this.init();
  }
};


/***/ }

/******/ });