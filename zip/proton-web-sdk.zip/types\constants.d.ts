export declare const WALLET_TYPES: {
    key: string;
    value: string;
}[];
