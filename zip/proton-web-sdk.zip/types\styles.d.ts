import { CustomStyleOptions } from ".";
declare const _default: (customStyleOptions: CustomStyleOptions | undefined) => string;
export default _default;
