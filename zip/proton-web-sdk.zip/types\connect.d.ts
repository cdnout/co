import { ConnectWalletArgs, ConnectWalletRet } from './types';
export declare const ConnectWallet: ({ linkOptions, transportOptions, selectorOptions }: ConnectWalletArgs) => Promise<ConnectWalletRet>;
