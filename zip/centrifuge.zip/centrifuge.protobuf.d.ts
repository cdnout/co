import Centrifuge = require('./centrifuge');

export = Centrifuge;
