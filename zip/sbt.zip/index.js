define([],function(){
    return {};
});
