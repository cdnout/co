define([],function(){
    return {};
});