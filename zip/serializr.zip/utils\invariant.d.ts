export default function invariant(condition: any, message: string, ...variables: any[]): asserts condition;
