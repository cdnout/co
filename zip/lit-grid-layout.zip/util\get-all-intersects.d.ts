import type { Layout, LayoutItem } from "../types";
export declare const getAllIntersects: (layout: Layout, layoutItem: LayoutItem) => Array<LayoutItem>;
//# sourceMappingURL=get-all-intersects.d.ts.map