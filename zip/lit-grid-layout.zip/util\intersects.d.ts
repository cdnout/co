import type { LayoutItem } from "../types";
export declare const intersects: (item1: LayoutItem, item2: LayoutItem) => boolean;
//# sourceMappingURL=intersects.d.ts.map