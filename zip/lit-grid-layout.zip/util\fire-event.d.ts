export declare const fireEvent: (target: EventTarget, event: string, detail?: Record<string, any>) => void;
//# sourceMappingURL=fire-event.d.ts.map