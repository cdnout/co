import type { Layout, LayoutItem } from "../types";
export declare const moveItem: (layout: Layout, item: LayoutItem, newPosX: number | undefined, newPosY: number | undefined, columns: number, isUserMove: boolean) => Layout;
//# sourceMappingURL=move-item.d.ts.map