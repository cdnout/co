export declare const getTouchIdentifier: (e: TouchEvent) => number;
//# sourceMappingURL=get-touch-identifier.d.ts.map