import type { Layout } from "../types";
export declare const condenseLayout: (layout: Layout) => Layout;
//# sourceMappingURL=condense-layout.d.ts.map