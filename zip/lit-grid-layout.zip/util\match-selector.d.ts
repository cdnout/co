export declare const matchesSelectorAndParentsTo: (ev: MouseEvent | TouchEvent, selector: string, baseNode: Node) => boolean;
//# sourceMappingURL=match-selector.d.ts.map