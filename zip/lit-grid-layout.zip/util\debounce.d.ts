export declare const debounce: <T extends Function>(func: T, wait: any, immediate?: boolean) => T;
//# sourceMappingURL=debounce.d.ts.map