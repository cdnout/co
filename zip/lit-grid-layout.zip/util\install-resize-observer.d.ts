export declare const installResizeObserver: () => Promise<void>;
//# sourceMappingURL=install-resize-observer.d.ts.map