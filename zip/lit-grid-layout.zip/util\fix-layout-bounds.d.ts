import type { LayoutItem } from "../types";
export declare const fixLayoutBounds: (layout: LayoutItem[], cols: number) => LayoutItem[];
//# sourceMappingURL=fix-layout-bounds.d.ts.map