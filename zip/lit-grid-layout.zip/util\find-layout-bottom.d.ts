import type { LayoutItem } from "../types";
export declare const findLayoutBottom: (layout: LayoutItem[]) => number;
//# sourceMappingURL=find-layout-bottom.d.ts.map