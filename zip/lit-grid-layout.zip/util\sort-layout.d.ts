import type { Layout } from "../types";
export declare const sortLayout: (layout: Layout) => Layout;
//# sourceMappingURL=sort-layout.d.ts.map