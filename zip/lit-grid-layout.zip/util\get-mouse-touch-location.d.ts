import type { MouseTouchLocation } from "../types";
export declare const getMouseTouchLocation: (ev: MouseEvent | TouchEvent, touchIdentifier: number | undefined) => MouseTouchLocation | undefined;
//# sourceMappingURL=get-mouse-touch-location.d.ts.map