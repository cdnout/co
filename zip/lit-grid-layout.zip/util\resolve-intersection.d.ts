import type { LayoutItem } from "../types";
export declare const resolveIntersection: (layout: LayoutItem[], item: LayoutItem, newYPos: number) => void;
//# sourceMappingURL=resolve-intersection.d.ts.map