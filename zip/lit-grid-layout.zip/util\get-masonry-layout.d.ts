import type { Layout } from "../types";
export declare const getMasonryLayout: (layout: Layout, columns: number) => Layout;
//# sourceMappingURL=get-masonry-layout.d.ts.map