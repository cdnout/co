import type { Layout } from "../types";
export declare const areLayoutsDifferent: (a: Layout, b: Layout) => boolean;
//# sourceMappingURL=are-layouts-different.d.ts.map