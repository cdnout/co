import type { LayoutItem } from "../types";
export declare const getItemItersect: (layout: LayoutItem[], layoutItem: LayoutItem) => LayoutItem | undefined;
//# sourceMappingURL=get-item-intersect.d.ts.map