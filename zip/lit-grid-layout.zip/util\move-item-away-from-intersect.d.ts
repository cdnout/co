import type { Layout, LayoutItem } from "../types";
export declare const moveItemAwayFromIntersect: (layout: Layout, intersectItem: LayoutItem, itemToMove: LayoutItem, cols: number, isUserMove: boolean) => Layout;
//# sourceMappingURL=move-item-away-from-intersect.d.ts.map