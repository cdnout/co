export default {
    Search: 'Suche',
    'No results found.': 'Keine Ergebnisse gefunden.',
    cancel: 'beenden'
};
