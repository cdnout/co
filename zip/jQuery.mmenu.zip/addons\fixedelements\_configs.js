var configs = {
    insertMethod: 'append',
    insertSelector: 'body'
};
export default configs;
