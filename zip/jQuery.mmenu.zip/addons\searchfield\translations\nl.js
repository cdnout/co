export default {
    Search: 'Zoeken',
    'No results found.': 'Geen resultaten gevonden.',
    cancel: 'annuleren'
};
