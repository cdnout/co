declare module "react-date-picker/dist/entry.nostyle" {
    import * as picker from "react-date-picker";
    export = picker;
}
