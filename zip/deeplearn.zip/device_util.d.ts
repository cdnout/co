export declare function isMobile(): boolean;
