import { Node } from './graph';
import { Operation } from './ops/op';
export declare function emitFromGraphNodes(nodes: Node[]): Operation[];
