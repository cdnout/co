"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var version = '0.5.1';
exports.version = version;
