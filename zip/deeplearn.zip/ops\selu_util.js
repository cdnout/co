"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SELU_SCALEALPHA = 1.7580993408473768599402175208123;
exports.SELU_SCALE = 1.0507009873554804934193349852946;
