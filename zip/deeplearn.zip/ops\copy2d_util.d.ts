export declare function validateShapes(sourceSize: [number, number], destSize: [number, number]): void;
