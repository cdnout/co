import { Tensor } from './tensor';
export declare function tensorToString(t: Tensor, verbose: boolean): string;
