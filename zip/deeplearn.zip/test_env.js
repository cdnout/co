"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("./kernels/backend_cpu");
require("./kernels/backend_webgl");
