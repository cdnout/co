declare const version = "0.5.1";
export { version };
