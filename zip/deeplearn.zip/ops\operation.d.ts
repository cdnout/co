export declare function operation(target: {}, name: string, descriptor: PropertyDescriptor): PropertyDescriptor;
