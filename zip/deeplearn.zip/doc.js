"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function doc(info) {
    return function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
    };
}
exports.doc = doc;
