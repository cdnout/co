import { Tensor } from '../tensor';
export declare function assertParamsValid(input: Tensor, begin: number[], size: number[]): void;
