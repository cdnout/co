export declare class BrowserUtil {
    static nextFrame(): Promise<void>;
}
