"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DataSource = (function () {
    function DataSource() {
    }
    return DataSource;
}());
exports.DataSource = DataSource;
