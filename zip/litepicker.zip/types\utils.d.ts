import { DateTime } from './datetime';
export declare function findNestedMonthItem(monthItem: Element): number;
export declare function dateIsLocked(date: DateTime, options: any, pickedDates: DateTime[]): boolean;
export declare function rangeIsLocked(days: DateTime[], options: any): boolean;
