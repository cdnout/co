declare global {
    interface Window {
        Litepicker: any;
    }
}
export {};
