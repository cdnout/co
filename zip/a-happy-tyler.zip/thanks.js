/*
 * Thank you all for an amazing summer!
 *
 * Although I couldn't meet any of you in person, I can't describe how
 * thankful I am to have had the opportunity to meet you all. I've never
 * worked with such smart, capable, and supportive people in my life!
 *
 * Thanks everyone, especially my mentor Sven, for treating me as a team member
 * and having the patience for my endless questions!
 */

export const AMAZING_PEOPLE = [
  "Sven S.",
  "Matt (IPv4) C.",
  "Andrew G.",
  "David P.",
  "Marwan F.",
  "Chris B.",
  "Gabi M.",
  "Kyle K.",
  "Kornel L.",
  "Pete Z.",
  "Yevgen S.",
  "Ivan N.",
  "Sam R.",
  "Ellie J.",
  "Judy C.",
  "Usman M.",
  "Michelle Z.",
  "Matthew P.",
  "John G-C.",
  "Dane K.",
  "Misha Y.",
  "Watson L.",
  "Kari L.",
  "Lucas P.",
  "Val V.",
  "Yuchen W.",
  "Greg B.",
  "Clement J.",
  "Jonas O.",
  "Zak C.",
  "Kevin F.",
  "Justin Z.",
  "Wen Q.",
  "Bani S.",
];
