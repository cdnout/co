// make console.log safe to use
window.console||(console={log:function(){}});