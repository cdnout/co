export declare const stripDiacritics: (str: string) => string;
