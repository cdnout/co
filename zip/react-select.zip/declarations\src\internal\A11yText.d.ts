/// <reference types="react" />
/** @jsx jsx */
import { jsx } from '@emotion/react';
declare const A11yText: (props: JSX.IntrinsicElements['span']) => jsx.JSX.Element;
export default A11yText;
