declare var __SERVER__: boolean;
declare var __VERSION__: string;
