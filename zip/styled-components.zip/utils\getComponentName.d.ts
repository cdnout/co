import { StyledTarget } from '../types';
export default function getComponentName(target: StyledTarget): string;
