export default function getNonce(): string | null;
