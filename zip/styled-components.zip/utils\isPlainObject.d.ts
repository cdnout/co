export default function isPlainObject(x: any): boolean;
