export declare const LIMIT = 200;
declare const _default: (displayName: string, componentId: string) => (className: string) => void;
export default _default;
