export declare const checkDynamicCreation: (displayName: string, componentId?: string | undefined) => void;
