import { ExtensibleObject } from '../types';
export declare const EMPTY_ARRAY: readonly any[];
export declare const EMPTY_OBJECT: Readonly<ExtensibleObject>;
