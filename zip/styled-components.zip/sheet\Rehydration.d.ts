import { Sheet } from './types';
export declare const outputSheet: (sheet: Sheet) => string;
export declare const rehydrateSheet: (sheet: Sheet) => void;
