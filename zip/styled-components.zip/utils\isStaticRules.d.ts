import { RuleSet } from '../types';
export default function isStaticRules<Props = unknown>(rules: RuleSet<Props>): boolean;
