export default function generateAlphabeticName(code: number): string;
