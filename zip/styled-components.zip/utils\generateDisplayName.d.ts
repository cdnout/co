import { StyledTarget } from '../types';
export default function generateDisplayName(target: StyledTarget): string;
