export default function isStatelessFunction(test: any): boolean;
