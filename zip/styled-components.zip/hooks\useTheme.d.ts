import { DefaultTheme } from '../models/ThemeProvider';
declare const useTheme: () => DefaultTheme | undefined;
export default useTheme;
