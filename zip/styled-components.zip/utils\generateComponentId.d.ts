export default function generateComponentId(str: string): string;
