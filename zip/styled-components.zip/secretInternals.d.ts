import StyleSheet from './sheet';
export declare const __PRIVATE__: {
    StyleSheet: typeof StyleSheet;
    mainSheet: StyleSheet;
};
