export default function isFunction(test: any): boolean;
