export declare const SEED = 5381;
export declare const phash: (h: number, x: string) => number;
export declare const hash: (x: string) => number;
