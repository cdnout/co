import { ExtensibleObject } from '../types';
export default function determineTheme(props: ExtensibleObject, providedTheme: any, defaultProps?: any): any;
