export declare const resetGroupIds: () => void;
export declare const getGroupForId: (id: string) => number;
export declare const getIdForGroup: (group: number) => void | string;
export declare const setGroupForId: (id: string, group: number) => void;
