/**
 * TODO: Explore using CSS.escape when it becomes more available
 * in evergreen browsers.
 */
export default function escape(str: string): string;
