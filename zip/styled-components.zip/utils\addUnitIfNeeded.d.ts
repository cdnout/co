export default function addUnitIfNeeded(name: string, value: any): string;
