import { StyledTarget } from '../types';
export default function isTag(target: StyledTarget): boolean;
