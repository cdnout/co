import styled from './constructors/styled';
export default styled;
