import { TinyDatePicker } from './tiny-date-picker';
import { TinyDatePickerOptions } from './types';
export declare function toTimeString(dt: Date, opts: TinyDatePickerOptions): string;
export declare function renderTimePicker(picker: TinyDatePicker): HTMLElement;
//# sourceMappingURL=time-picker.d.ts.map