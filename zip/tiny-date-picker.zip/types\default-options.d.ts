import { TinyDatePickerOptions } from './types';
export declare function defaultOptions(): TinyDatePickerOptions;
//# sourceMappingURL=default-options.d.ts.map