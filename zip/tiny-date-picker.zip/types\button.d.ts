export declare function button(className: string, attrs: any, content: any): HTMLElement;
//# sourceMappingURL=button.d.ts.map