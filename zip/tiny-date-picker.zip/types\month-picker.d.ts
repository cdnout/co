import { TinyDatePicker } from './tiny-date-picker';
export declare function showMonthPicker(picker: TinyDatePicker): void;
//# sourceMappingURL=month-picker.d.ts.map