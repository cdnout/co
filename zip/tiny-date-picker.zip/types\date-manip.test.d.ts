export {};
//# sourceMappingURL=date-manip.test.d.ts.map