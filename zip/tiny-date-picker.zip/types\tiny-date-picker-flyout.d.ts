import { TinyDatePicker } from './tiny-date-picker';
export declare function tinyDatePickerFlyout(picker: TinyDatePicker, input: HTMLInputElement): void;
//# sourceMappingURL=tiny-date-picker-flyout.d.ts.map