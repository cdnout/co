import { TinyDatePicker } from './tiny-date-picker';
export declare function showYearPicker(picker: TinyDatePicker): void;
//# sourceMappingURL=year-picker.d.ts.map