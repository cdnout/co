export declare function checkParenthesis(opening: string, closing: string, target: string, nextChar: string): boolean | undefined;
export declare const maximumAttrLength: number;
export declare function isInsideAttribute(prevFragment: string): boolean;
export declare function isInsideAnchorTag(target: string, fullInput: string, targetEnd: number): boolean;
