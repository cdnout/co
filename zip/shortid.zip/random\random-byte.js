module.exports = require('nanoid/random');
