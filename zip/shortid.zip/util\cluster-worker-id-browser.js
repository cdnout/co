'use strict';

module.exports = 0;
