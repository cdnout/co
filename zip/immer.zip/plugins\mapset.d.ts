export declare function enableMapSet(): void;
//# sourceMappingURL=mapset.d.ts.map