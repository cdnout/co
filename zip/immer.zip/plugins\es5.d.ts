export declare function enableES5(): void;
//# sourceMappingURL=es5.d.ts.map