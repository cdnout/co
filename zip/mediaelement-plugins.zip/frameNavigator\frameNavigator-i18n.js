'use strict';

if (mejs.i18n.ca !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.cs !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.de !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.es !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.fr !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.hr !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.hu !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.it !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.ja !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.ko !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.nl !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.pl !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.pt !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n['pt-BR'] !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.ro !== undefined) {
	//mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.ru !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.sk !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.sv !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.uk !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n.zh !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}
if (mejs.i18n['zh-CN'] !== undefined) {
    //mejs.i18n.en["mejs.frame-rate"] = "Media frame rate (select according to your video source)";
    //mejs.i18n.en["mejs.step-fwd"] = "Step forward";
    //mejs.i18n.en["mejs.step-back"] = "Step back";
}