"use strict";

if(mejs.i18n.es !== undefined) {
  mejs.i18n.es['mejs.picture-in-pictureText'] = 'Picture in picture';
}
if (mejs.i18n.de !== undefined) {
	mejs.i18n.de['mejs.picture-in-pictureText'] = 'Bild in Bild';
}
if(mejs.i18n.fr !== undefined) {
  mejs.i18n.fr['mejs.picture-in-pictureText'] = 'Image dans l’image';
}
if(mejs.i18n.es !== undefined) {
  mejs.i18n.es['mejs.picture-in-pictureText'] = 'Imagen dentro de imagen';
}


// TODO Add more languages for the title attribute
