export { MaterializeDirective, MaterializeAction } from "./materialize-directive";
export { MaterializeModule } from "./materialize-module";
export declare function toast(...args: any[]): void;
