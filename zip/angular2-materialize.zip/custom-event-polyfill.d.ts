export declare function CustomEvent(type: any, detail?: any, params?: {
    bubbles: boolean;
    cancelable: boolean;
}): CustomEvent;
