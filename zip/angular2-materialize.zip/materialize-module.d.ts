import { ModuleWithProviders } from '@angular/core';
export declare class MaterializeModule {
    static forRoot(): ModuleWithProviders;
}
