export class WaitError extends Error {
}
