import { config } from './config';
export function logError(...args) {
    config.logError(...args);
}
