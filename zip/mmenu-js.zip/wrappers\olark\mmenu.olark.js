export default function () {
    this.conf.offCanvas.page.noSelector.push('#olark');
}
;
