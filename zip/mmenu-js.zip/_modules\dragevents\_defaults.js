/** How far from the sides the gesture can start. */
export var area = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
};
/** Tresholds for gestures. */
export var treshold = {
    start: 15,
    swipe: 15
};
