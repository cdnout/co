var configs = {
    breadcrumbs: {
        separator: '/',
        removeFirst: false
    }
};
export default configs;
