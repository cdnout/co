export default function () {
    this.conf.classNames.selected = 'active';
}
;
