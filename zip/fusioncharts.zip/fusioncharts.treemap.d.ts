
import { FusionChartStatic } from 'fusioncharts';

declare namespace Treemap {}
declare var Treemap: (H: FusionChartStatic) => FusionChartStatic;
export = Treemap;
export as namespace Treemap;

