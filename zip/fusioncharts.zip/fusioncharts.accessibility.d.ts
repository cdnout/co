
import { FusionChartStatic } from 'fusioncharts';

declare namespace Accessibility {}
declare var Accessibility: (H: FusionChartStatic) => FusionChartStatic;
export = Accessibility;
export as namespace Accessibility;

