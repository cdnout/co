// From https://github.com/sindresorhus/auto-bind/blob/master/index.js
// Bundled because of Create React App…
'use strict'; // Gets all non-builtin properties up the prototype chain

const getAllProperties = object => {
  const props = new Set();

  do {
    for (const key of Reflect.ownKeys(object)) {
      props.add([object, key]);
    }
  } while ((object = Reflect.getPrototypeOf(object)) && object !== Object.prototype);

  return props;
};

module.exports = (self, options) => {
  options = Object.assign({}, options);

  const filter = key => {
    const match = pattern => typeof pattern === 'string' ? key === pattern : pattern.test(key);

    if (options.include) {
      return options.include.some(match);
    }

    if (options.exclude) {
      return !options.exclude.some(match);
    }

    return true;
  };

  for (const [object, key] of getAllProperties(self.constructor.prototype)) {
    if (key === 'constructor' || !filter(key)) {
      continue;
    }

    const descriptor = Reflect.getOwnPropertyDescriptor(object, key);

    if (descriptor && typeof descriptor.value === 'function') {
      self[key] = self[key].bind(self);
    }
  }

  return self;
};

const excludedReactMethods = ['componentWillMount', 'UNSAFE_componentWillMount', 'render', 'getSnapshotBeforeUpdate', 'componentDidMount', 'componentWillReceiveProps', 'UNSAFE_componentWillReceiveProps', 'shouldComponentUpdate', 'componentWillUpdate', 'UNSAFE_componentWillUpdate', 'componentDidUpdate', 'componentWillUnmount', 'componentDidCatch', 'setState', 'forceUpdate'];

module.exports.react = (self, options) => {
  options = Object.assign({}, options);
  options.exclude = (options.exclude || []).concat(excludedReactMethods);
  return module.exports(self, options);
};