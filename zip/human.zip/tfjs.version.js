/*
  Human
  homepage: <https://github.com/vladmandic/human>
  author: <https://github.com/vladmandic>'
*/

var e="3.15.0";var s="3.15.0";var t="3.15.0";var r="3.15.0";var l="3.15.0";var i="3.15.0";var a="3.15.0";var n="3.15.0";var G={tfjs:e,"tfjs-core":s,"tfjs-data":t,"tfjs-layers":r,"tfjs-converter":l,"tfjs-backend-cpu":i,"tfjs-backend-webgl":a,"tfjs-backend-wasm":n};export{G as version};
