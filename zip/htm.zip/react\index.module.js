import{createElement as r}from"react";import m from"htm";var o=m.bind(r);export{o as html};
