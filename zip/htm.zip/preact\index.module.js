import{h as r,Component as o,render as t}from"preact";export{h,render,Component}from"preact";import e from"htm";var m=e.bind(r);export{m as html};
