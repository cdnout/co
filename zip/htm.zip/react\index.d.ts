import * as React from 'react';
declare const html: (strings: TemplateStringsArray, ...values: any[]) => React.ReactElement;
