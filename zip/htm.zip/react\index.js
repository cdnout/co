var e,t=require("react"),r=((e=require("htm"))&&"object"==typeof e&&"default"in e?e.default:e).bind(t.createElement);exports.html=r;
