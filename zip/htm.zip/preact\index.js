var e,r=require("preact"),t=((e=require("htm"))&&"object"==typeof e&&"default"in e?e.default:e).bind(r.h);exports.h=r.h,exports.render=r.render,exports.Component=r.Component,exports.html=t;
