(function ($) {
  Object.assign($.fn.checkboxpicker.defaults, {
    offLabel: 'Нет',
    onLabel: 'Да',
    warningMessage: 'Bootstrap-checkbox не поддерживает использование внутри label элемента.'
  });
})(jQuery);