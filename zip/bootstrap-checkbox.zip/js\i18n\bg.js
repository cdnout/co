(function ($) {
  Object.assign($.fn.checkboxpicker.defaults, {
    offLabel: 'Не',
    onLabel: 'Да',
    warningMessage: 'Bootstrap-checkbox не поддържа checkbox в label елемент.'
  });
})(jQuery);