/// <reference types="react" />
export default function Exclude(): JSX.Element;
