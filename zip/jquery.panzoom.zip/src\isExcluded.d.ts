import { PanzoomOptions } from './types';
export default function isExcluded(elem: Element, options: PanzoomOptions): boolean;
