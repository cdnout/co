export default function shallowClone(obj: any): any;
