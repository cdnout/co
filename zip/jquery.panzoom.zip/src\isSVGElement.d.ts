export default function isSVGElement(elem: HTMLElement | SVGElement): boolean;
