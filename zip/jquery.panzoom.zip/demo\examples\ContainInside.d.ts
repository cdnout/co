/// <reference types="react" />
export default function ContainInside(): JSX.Element;
