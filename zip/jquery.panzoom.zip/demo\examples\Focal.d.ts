/// <reference types="react" />
export default function Focal(): JSX.Element;
