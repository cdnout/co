/// <reference types="react" />
export default function SVG(): JSX.Element;
