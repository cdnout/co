/// <reference types="react" />
export default function Buttons(): JSX.Element;
