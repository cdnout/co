/// <reference types="react" />
export default function ContainOutside(): JSX.Element;
