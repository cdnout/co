interface Utils {
    [key: string]: Function;
}
declare const utils: Utils;
export default utils;
