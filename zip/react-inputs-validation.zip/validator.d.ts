interface Validator {
    [key: string]: Function;
}
declare const validator: Validator;
export default validator;
