/*!
 * vue-validator v2.1.3 
 * (c) 2016 kazuya kawaguchi
 * Released under the MIT License.
 */
!function(e,n){"object"==typeof exports&&"undefined"!=typeof module?module.exports=n():"function"==typeof define&&define.amd?define(n):e.VueValidator=n()}(this,function(){"use strict";function e(e){arguments.length<=1||void 0===arguments[1]?{}:arguments[1];e.prototype.$add=function(e,n){return e+n}}return e.version="2.1.3","undefined"!=typeof window&&window.Vue&&window.Vue.use(e),e});