"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

var _registerCSSInterfaceWithDefaultTheme = _interopRequireDefault(require("./utils/registerCSSInterfaceWithDefaultTheme"));

(0, _registerCSSInterfaceWithDefaultTheme["default"])();