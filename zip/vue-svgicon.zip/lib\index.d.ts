#!/usr/bin/env node
/**
 * build svg icon
 * @author Allenice
 * @since 2017-02-17
 */
export {};
