import { GeocoderControl as Geocoder } from './control';
export default Geocoder;
