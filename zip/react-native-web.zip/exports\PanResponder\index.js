import PanResponder from '../../vendor/react-native/PanResponder';
export default PanResponder;