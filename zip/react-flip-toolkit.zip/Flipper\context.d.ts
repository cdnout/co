/// <reference types="react" />
import { FlipCallbacks } from 'flip-toolkit/lib/types';
export declare const FlipContext: import("react").Context<FlipCallbacks>;
export declare const PortalContext: import("react").Context<string>;
