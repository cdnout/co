import { FunctionComponent } from 'react';
declare const ExitContainer: FunctionComponent;
export default ExitContainer;
