import { spring } from 'flip-toolkit';
export default spring;
