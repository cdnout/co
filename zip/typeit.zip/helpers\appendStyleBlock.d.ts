declare const _default: (styles: string, id?: string) => void;
export default _default;
