declare const _default: <T>(value: any) => T[];
/**
 * Converts value as within array, unless the value itself already is one.
 */
export default _default;
