declare let select: (selector: string, element?: Node, all?: boolean) => Node | NodeList | null;
export default select;
