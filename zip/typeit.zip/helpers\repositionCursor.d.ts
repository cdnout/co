declare const _default: (element: Node, allChars: any[], newCursorPosition: number) => void;
export default _default;
