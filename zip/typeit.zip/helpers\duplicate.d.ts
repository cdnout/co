declare const _default: <T>(value: T, times: number) => T[];
export default _default;
