import { Options, TypeItInstance } from "./types";
export declare type TypeItOptions = Options;
declare const TypeIt: TypeItInstance;
export default TypeIt;
