import { Element } from "../types";
declare let expandTextNodes: (element: Element) => Element;
export default expandTextNodes;
