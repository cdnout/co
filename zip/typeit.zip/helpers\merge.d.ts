declare const _default: (originalObj: any, newObj: any) => any;
export default _default;
