declare const _default: (element: HTMLElement, func: Function) => void;
export default _default;
