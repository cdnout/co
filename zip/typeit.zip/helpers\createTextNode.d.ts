declare const _default: (content: string) => Text;
export default _default;
