import { Element } from "../types";
declare const _default: (node: Element | null) => void;
/**
 * @param {object} HTML node
 */
export default _default;
