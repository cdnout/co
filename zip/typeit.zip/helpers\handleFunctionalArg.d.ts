declare let handleFunctionalArg: <T>(arg: any) => T;
export default handleFunctionalArg;
