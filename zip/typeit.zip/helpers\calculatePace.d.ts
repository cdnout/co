import { Options } from "../types";
/**
 * [typePace, deletePace]
 */
export default function (options: Options): number[];
