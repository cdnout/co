declare const _default: (el: any) => CSSStyleDeclaration;
export default _default;
