import { Element } from "../types";
declare const _default: (el: any) => Element;
export default _default;
