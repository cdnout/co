declare const _default: (thing: any) => boolean;
export default _default;
