import { Element } from "../types";
export default function (thing: string | Element): Element;
