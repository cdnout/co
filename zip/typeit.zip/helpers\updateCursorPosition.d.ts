declare let updateCursorPosition: (steps: number, cursorPosition: number, printedCharacters: Element[]) => number;
export default updateCursorPosition;
