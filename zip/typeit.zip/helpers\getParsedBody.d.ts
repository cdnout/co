import { Element } from "../types";
declare const _default: (content: any) => Element;
/**
 * Parse a string as HTML and return the body
 * of the parsed document, with all text nodes expanded.
 */
export default _default;
