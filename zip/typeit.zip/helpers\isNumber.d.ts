declare const _default: (value: any) => boolean;
export default _default;
