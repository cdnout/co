declare const _default: (value: number, range: number) => number;
export default _default;
