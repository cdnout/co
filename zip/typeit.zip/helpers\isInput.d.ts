declare const _default: (el: HTMLElement) => boolean;
export default _default;
