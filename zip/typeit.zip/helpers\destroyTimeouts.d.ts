declare const _default: (timeouts: number[]) => [];
export default _default;
