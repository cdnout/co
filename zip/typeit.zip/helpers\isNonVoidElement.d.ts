declare const _default: (el: any) => boolean;
export default _default;
