export var tabbarHeight = 48;
//# sourceMappingURL=constants.js.map