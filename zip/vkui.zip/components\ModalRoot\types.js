export var ModalType;

(function (ModalType) {
  ModalType["PAGE"] = "page";
  ModalType["CARD"] = "card";
})(ModalType || (ModalType = {}));
//# sourceMappingURL=types.js.map