/**
 * Вычисляет цвет InitialsAvatar на основании переданного идентификатора объекта
 */
export function calcInitialsAvatarColor(objectId) {
  return objectId % 6 + 1;
}
//# sourceMappingURL=avatar.js.map