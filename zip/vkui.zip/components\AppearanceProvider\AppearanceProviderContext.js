import * as React from "react";
import { Appearance } from "../../helpers/scheme";
export var AppearanceProviderContext = /*#__PURE__*/React.createContext(Appearance.LIGHT);
//# sourceMappingURL=AppearanceProviderContext.js.map