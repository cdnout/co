import * as React from "react";
export var AppRootContext = /*#__PURE__*/React.createContext({
  portalRoot: null
});
//# sourceMappingURL=AppRootContext.js.map