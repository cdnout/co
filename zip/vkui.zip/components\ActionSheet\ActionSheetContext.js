import * as React from "react";
export var ActionSheetContext = /*#__PURE__*/React.createContext({});
//# sourceMappingURL=ActionSheetContext.js.map