import * as React from "react";
import { noop } from "../../lib/utils";
export var ListContext = /*#__PURE__*/React.createContext({
  toggleDrag: noop
});
//# sourceMappingURL=ListContext.js.map