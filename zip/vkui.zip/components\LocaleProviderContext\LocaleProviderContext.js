import * as React from "react";
export var LocaleProviderContext = /*#__PURE__*/React.createContext(undefined);
//# sourceMappingURL=LocaleProviderContext.js.map