export var MODAL_PAGE_DEFAULT_PERCENT_HEIGHT = 75;
export var PERCENT_OPENED = 0;
export var PERCENT_CLOSED = 100;
//# sourceMappingURL=constants.js.map