export declare function tag(selector:string):any;
export declare function template(tpl:string):any;
export declare function useShadow(value:boolean):any;