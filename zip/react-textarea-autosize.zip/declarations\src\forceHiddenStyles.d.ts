declare const forceHiddenStyles: (node: HTMLElement) => void;
export default forceHiddenStyles;
