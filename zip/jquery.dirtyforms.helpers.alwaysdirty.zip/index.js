/*!
Always dirty helper module (for jQuery Dirty Forms) | v2.0.0 | github.com/snikch/jquery.dirtyforms
(c) 2015 Mal Curtis
License MIT
*/
!function(r,n,i,t){var u={isDirty:function(r){return!0}};r.DirtyForms.helpers.push(u)}(jQuery,window,document);
//# sourceMappingURL=jquery.dirtyforms.helpers.alwaysdirty.min.js.map
