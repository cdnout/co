videojs.addLanguage('es', {
  "Device": "Dispositivo",
  "Record": "Grabar",
  "Stop": "Parar",
  "Image": "Image",
  "Retry": "Reintentar",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});