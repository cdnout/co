videojs.addLanguage('af', {
  "Device": "Toestel",
  "Record": "Neem op",
  "Stop": "Stop",
  "Image": "Beeld",
  "Retry": "Probeer weer",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});