videojs.addLanguage('fy', {
  "Device": "Apparaat",
  "Record": "Opnimme",
  "Stop": "Stop",
  "Image": "Ôfbylding",
  "Retry": "Op 'e nij",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});