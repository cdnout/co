videojs.addLanguage('gl', {
  "Device": "Dispositivo",
  "Record": "Grabar",
  "Stop": "Parar",
  "Image": "Imaxe",
  "Retry": "Reintentar",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});