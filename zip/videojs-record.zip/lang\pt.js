videojs.addLanguage('pt', {
  "Device": "Aparelho",
  "Record": "Gravar",
  "Stop": "Stop",
  "Image": "Imagem",
  "Retry": "Fazer de novo",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});