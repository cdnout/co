videojs.addLanguage('nl', {
  "Device": "Apparaat",
  "Record": "Opnemen",
  "Stop": "Stop",
  "Image": "Afbeelding",
  "Retry": "Opnieuw",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});