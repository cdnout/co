videojs.addLanguage('de', {
  "Device": "Gerät",
  "Record": "Aufnahmen",
  "Stop": "Stop",
  "Image": "Bild",
  "Retry": "Wiederholen",
  "REC": "REC",
  "Picture in Picture": "Bild im Bild"
});