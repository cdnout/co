videojs.addLanguage('fr', {
  "Device": "Appareil",
  "Record": "Enregistrer",
  "Stop": "Arrête",
  "Image": "Image",
  "Retry": "Réessayer",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});