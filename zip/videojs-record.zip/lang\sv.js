videojs.addLanguage('sv', {
  "Device": "Apparat",
  "Record": "Spela in",
  "Stop": "Stop",
  "Image": "Bild",
  "Retry": "Försöka igen",
  "REC": "REC",
  "Picture in Picture": "Bild i bild"
});