videojs.addLanguage('it', {
  "Device": "Dispositivo",
  "Record": "Disco",
  "Stop": "Fermata",
  "Image": "Immagine",
  "Retry": "Riprova",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});