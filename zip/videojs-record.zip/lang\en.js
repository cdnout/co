videojs.addLanguage('en', {
  "Device": "Device",
  "Record": "Record",
  "Stop": "Stop",
  "Image": "Image",
  "Retry": "Retry",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});