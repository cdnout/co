videojs.addLanguage('fi', {
  "Device": "Laite",
  "Record": "Nauhoita",
  "Stop": "Lopeta",
  "Image": "Kuva",
  "Retry": "Uudestaan",
  "REC": "REC",
  "Picture in Picture": "Picture in Picture"
});