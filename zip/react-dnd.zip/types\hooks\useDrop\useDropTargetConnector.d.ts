import { TargetConnector } from '../../internals';
import { DropTargetOptions } from '../../types';
export declare function useDropTargetConnector(options: DropTargetOptions): TargetConnector;
