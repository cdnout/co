import { TargetConnector } from '../../internals';
export declare function useConnectDropTarget(connector: TargetConnector): any;
