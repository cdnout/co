export declare function wrapConnectorHooks(hooks: any): any;
