import { SourceConnector } from '../../internals';
export declare function useConnectDragSource(connector: SourceConnector): any;
export declare function useConnectDragPreview(connector: SourceConnector): any;
