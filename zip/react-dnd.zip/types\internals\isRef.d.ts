export interface Ref<T> {
    current: T;
}
export declare function isRef(obj: unknown): boolean;
