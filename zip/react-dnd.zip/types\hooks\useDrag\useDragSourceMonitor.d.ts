import { DragSourceMonitor } from '../../types';
export declare function useDragSourceMonitor(): DragSourceMonitor;
