import { DropTargetMonitor } from '../../types';
export declare function useDropTargetMonitor(): DropTargetMonitor;
