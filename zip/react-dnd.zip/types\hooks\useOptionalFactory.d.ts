import { FactoryOrInstance } from './types';
export declare function useOptionalFactory<T>(arg: FactoryOrInstance<T>, deps?: unknown[]): T;
