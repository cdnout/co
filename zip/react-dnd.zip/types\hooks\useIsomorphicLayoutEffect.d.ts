import { useEffect } from 'react';
export declare const useIsomorphicLayoutEffect: typeof useEffect;
