// Error : Unexpected token: keyword (const)
// Line  : 11
// Col   : 0