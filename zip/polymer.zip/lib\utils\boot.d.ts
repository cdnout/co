// tslint:disable:variable-name Describing an API that's defined elsewhere.


export {};
