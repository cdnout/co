import { Abbreviation } from '@emmetio/abbreviation';
import { Config } from '../../config';
export default function slim(abbr: Abbreviation, config: Config): string;
