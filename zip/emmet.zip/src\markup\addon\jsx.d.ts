import { AbbreviationNode } from '@emmetio/abbreviation';
/**
 * JSX transformer: replaces `class` and `for` attributes with `className` and
 * `htmlFor` attributes respectively
 */
export default function jsx(node: AbbreviationNode): void;
