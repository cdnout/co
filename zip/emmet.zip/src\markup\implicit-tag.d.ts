import { AbbreviationNode } from '@emmetio/abbreviation';
import { Container } from './utils';
import { Config } from '../config';
export default function implicitTag(node: AbbreviationNode, ancestors: Container[], config: Config): void;
export declare function resolveImplicitTag(node: AbbreviationNode, ancestors: Container[], config: Config): void;
