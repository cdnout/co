import { AbbreviationNode } from '@emmetio/abbreviation';
import { Container } from '../utils';
import { Config } from '../../config';
export default function lorem(node: AbbreviationNode, ancestors: Container[], config: Config): void;
