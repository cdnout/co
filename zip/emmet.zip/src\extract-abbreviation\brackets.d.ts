export declare const enum Brackets {
    SquareL = 91,
    SquareR = 93,
    RoundL = 40,
    RoundR = 41,
    CurlyL = 123,
    CurlyR = 125
}
export declare const bracePairs: {
    91: Brackets;
    40: Brackets;
    123: Brackets;
};
