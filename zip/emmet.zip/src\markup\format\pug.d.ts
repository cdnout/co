import { Abbreviation } from '@emmetio/abbreviation';
import { Config } from '../../config';
export default function pug(abbr: Abbreviation, config: Config): string;
