import { CSSAbbreviation } from '@emmetio/css-abbreviation';
import { Config } from '../config';
export default function css(abbr: CSSAbbreviation, config: Config): string;
