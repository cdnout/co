import { Abbreviation } from '@emmetio/abbreviation';
import { Config } from '../../config';
export default function haml(abbr: Abbreviation, config: Config): string;
