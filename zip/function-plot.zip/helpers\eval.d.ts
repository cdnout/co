declare const builtIn: (meta: any, property: string, variables: any) => any;
declare const interval: (meta: any, property: string, variables: any) => any;
export { builtIn, interval };
