"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.interval = exports.builtIn = void 0;
const builtIn_1 = __importDefault(require("./builtIn"));
exports.builtIn = builtIn_1.default;
const interval_1 = __importDefault(require("./interval"));
exports.interval = interval_1.default;
//# sourceMappingURL=index.js.map