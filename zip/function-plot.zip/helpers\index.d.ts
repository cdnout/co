import { Selection } from 'd3-selection';
import { Chart } from '../index';
export default function helpers(chart: Chart): (selection: Selection<any, any, any, any>) => void;
