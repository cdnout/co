import { Meta } from '@storybook/react';
declare const _default: Meta<import("@storybook/react").Args>;
export default _default;
export declare const PlottingACurve: any;
export declare const AdditionalOptions: any;
