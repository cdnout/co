import { IGunStatic } from './types/static';
declare const Gun: IGunStatic;
export = Gun;
