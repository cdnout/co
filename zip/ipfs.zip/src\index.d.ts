declare const _exports: {
    create: typeof import("ipfs-core/src/components").create;
    crypto: typeof import("libp2p-crypto");
    isIPFS: any;
    CID: typeof import("cids");
    multiaddr: typeof import("multiaddr");
    multibase: any;
    multihash: any;
    multihashing: any;
    multicodec: any;
    PeerId: typeof import("peer-id");
    globSource: any;
    urlSource: any;
};
export = _exports;
export type IPFS = import("ipfs-core/src/components");
//# sourceMappingURL=index.d.ts.map