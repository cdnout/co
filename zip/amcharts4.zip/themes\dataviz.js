export { default } from "../.internal/themes/dataviz";
//# sourceMappingURL=dataviz.js.map