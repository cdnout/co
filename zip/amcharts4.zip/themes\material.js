export { default } from "../.internal/themes/material";
//# sourceMappingURL=material.js.map