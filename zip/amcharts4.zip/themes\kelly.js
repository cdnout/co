export { default } from "../.internal/themes/kelly";
//# sourceMappingURL=kelly.js.map