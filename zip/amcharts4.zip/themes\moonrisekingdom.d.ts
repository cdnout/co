export { default } from "../.internal/themes/moonrisekingdom";
