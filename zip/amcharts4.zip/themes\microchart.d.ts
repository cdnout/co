export { default } from "../.internal/themes/microchart";
