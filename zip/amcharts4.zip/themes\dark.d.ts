export { default } from "../.internal/themes/dark";
