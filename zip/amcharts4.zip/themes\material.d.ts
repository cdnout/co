export { default } from "../.internal/themes/material";
