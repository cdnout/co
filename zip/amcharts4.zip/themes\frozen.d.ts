export { default } from "../.internal/themes/frozen";
