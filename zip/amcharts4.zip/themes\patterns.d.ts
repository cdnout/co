export { default } from "../.internal/themes/patterns";
