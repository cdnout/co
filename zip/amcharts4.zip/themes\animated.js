export { default } from "../.internal/themes/animated";
//# sourceMappingURL=animated.js.map