export * from "../.internal/plugins/regression/Regression";
//# sourceMappingURL=regression.js.map