export { default } from "../.internal/themes/amchartsdark";
//# sourceMappingURL=amchartsdark.js.map