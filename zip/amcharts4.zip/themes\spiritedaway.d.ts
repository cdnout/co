export { default } from "../.internal/themes/spiritedaway";
