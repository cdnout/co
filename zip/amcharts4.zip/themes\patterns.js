export { default } from "../.internal/themes/patterns";
//# sourceMappingURL=patterns.js.map