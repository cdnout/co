export { default } from "../.internal/themes/moonrisekingdom";
//# sourceMappingURL=moonrisekingdom.js.map