export { default } from "../.internal/themes/amcharts";
//# sourceMappingURL=amcharts.js.map