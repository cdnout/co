export { default } from "../.internal/themes/dark";
//# sourceMappingURL=dark.js.map