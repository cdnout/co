export { default } from "../.internal/themes/amchartsdark";
