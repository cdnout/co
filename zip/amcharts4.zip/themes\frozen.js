export { default } from "../.internal/themes/frozen";
//# sourceMappingURL=frozen.js.map