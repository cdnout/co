export { default } from "../.internal/themes/animated";
