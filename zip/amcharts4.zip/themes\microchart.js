export { default } from "../.internal/themes/microchart";
//# sourceMappingURL=microchart.js.map