export { default } from "../.internal/themes/amcharts";
