/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(n){"use strict";provide((function(){return function(t,c,e){var i;function u(){var r=this,a=arguments,o=e&&!i;function f(){u.cancel(),!e&&t.apply(r,a)}u.cancel(),i=n(f,parseInt(c,10)||200),o&&t.apply(r,a)}return u.cancel=function(){i=clearTimeout(i)},u}}))}(setTimeout);
//# sourceMappingURL=debounce.js.map
