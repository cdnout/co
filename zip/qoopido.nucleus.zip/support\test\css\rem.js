/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(e){"use strict";provide(["/demand/pledge"],(function(t){var r=t.defer(),n=e.createElement("div").style;try{n.fontSize="3rem"}catch(e){}return/rem/.test(n.fontSize)?r.resolve():r.reject(),r.pledge}))}(document);
//# sourceMappingURL=rem.js.map
