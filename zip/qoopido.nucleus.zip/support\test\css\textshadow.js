/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(){"use strict";provide(["/demand/pledge","../../css/property"],(function(e,r){var t=e.defer(),d=r("text-shadow");return d?t.resolve(d):t.reject(),t.pledge}))}();
//# sourceMappingURL=textshadow.js.map
