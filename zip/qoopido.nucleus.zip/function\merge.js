/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(){"use strict";provide(["/demand/validator/isObject","/demand/function/iterate"],(function(n,t){return function i(){for(var o,e,d,r=arguments[0],u=1;void 0!==(o=arguments[u]);u++)t(o,(function(t,o){e=r[t],void 0!==o&&(n(o)?(d=n(e),e=void 0!==o.length?d&&void 0!==e.length?e:[]:d&&void 0===e.length?e:{},r[t]=i(e,o)):r[t]=o)}));return r}}))}();
//# sourceMappingURL=merge.js.map
