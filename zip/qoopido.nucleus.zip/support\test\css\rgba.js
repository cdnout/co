/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(e){"use strict";provide(["/demand/pledge"],(function(r){var t=r.defer(),c=e.createElement("div").style,d="backgroundColor";try{c[d]="rgba(0,0,0,.5)"}catch(e){}return/rgba/.test(c[d])?t.resolve():t.reject(),t.pledge}))}(document);
//# sourceMappingURL=rgba.js.map
