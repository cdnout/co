/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(e){"use strict";provide(["/demand/pledge"],(function(A){var t=A.defer(),d=e.createElement("img");return d.onload=function(){1===d.width&&1===d.height?t.resolve():t.reject(),delete d.onload},d.src="data:image/gif;base64,R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==",t.pledge}))}(document);
//# sourceMappingURL=datauri.js.map
