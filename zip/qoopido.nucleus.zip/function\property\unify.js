/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(){"use strict";provide(["../string/lcfirst","../string/ucfirst"],(function(r,t){var i=/^-?(?:webkit|khtml|icab|moz|ms|o)([A-Z]|-[a-z])/,n=/-([a-z])/gi;function c(r,i){return t(i)}return function(t){return r(r(t).replace(i,"$1").replace(n,c))}}))}();
//# sourceMappingURL=unify.js.map
