/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(e){"use strict";provide(["/demand/pledge"],(function(n){var r=n.defer();return"canPlayType"in e.createElement("video")?r.resolve():r.reject(),r.pledge}))}(document);
//# sourceMappingURL=video.js.map
