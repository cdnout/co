/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(e){"use strict";provide(["/demand/pledge"],(function(t){var n=t.defer(),r=e.createElement("canvas");return"getContext"in r&&r.getContext("2d")?n.resolve():n.reject(),n.pledge}))}(document);
//# sourceMappingURL=canvas.js.map
