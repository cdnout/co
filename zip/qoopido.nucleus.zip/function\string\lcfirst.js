/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(){"use strict";provide((function(){return function(t){return t.charAt(0).toLowerCase()+t.slice(1)}}))}();
//# sourceMappingURL=lcfirst.js.map
