/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(e){"use strict";provide(["/demand/pledge"],(function(t){var r=t.defer(),n="createElementNS"in e&&e.createElementNS("http://www.w3.org/2000/svg","svg");return n&&"createSVGRect"in n?r.resolve():r.reject(),r.pledge}))}(document);
//# sourceMappingURL=svg.js.map
