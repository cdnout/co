/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(n){"use strict";provide(["/demand/validator/isObject","/demand/validator/isTypeOf","./property"],(function(t,i,r){var e={};return function(u){var l,o,a,d,c=t(arguments[1])?arguments[1]:null,f=!!arguments[c?2:1],s=null;return(l=(c=c||n)===n?"#window":c.nodeName)&&(s=(o=e[l]=e[l]||{})[u]=e[l][u]||null),null===s&&(s=!1,(a=r(u,c))&&(d=c[a])&&(i(d,"function")||t(d))&&(s=a),o&&(o[u]=s)),s&&f?c[s]:s}}))}(this);
//# sourceMappingURL=method.js.map
