/**! Qoopido.nucleus 3.2.12 | http://nucleus.qoopido.com | (c) 2021 Dirk Lueth */
!function(){"use strict";provide(["/demand/pledge","../../css/property"],(function(e,r){var d=e.defer(),t=r("border-radius");return t?d.resolve(t):d.reject(),d.pledge}))}();
//# sourceMappingURL=borderradius.js.map
