/**
 * @author bdwebdesign.pl
 */
jQuery.paramquery.pqGrid.regional['pl'] = {
    strAdd: "Dodaj",
    strDelete: "Usu?",
    strEdit: "Edytuj",
    strLoading: "?adowanie...",
    strNextResult: "Nast?pny wynik",
    strNoRows: "Brak wynik�w do wy?wietlenia.",
    strNothingFound: "Nic nie znaleziono",
    strPrevResult: "Poprzedni wynik",
    strSearch: "Szukaj",
    strSelectedmatches: "Zaznaczone {0} z {1} pasuj?cych"
};
jQuery.paramquery.pqPager.regional['pl'] = {
    strDisplay: "Wy?wietlanie {0} do {1} z {2} element�w.",
    strFirstPage: "Pierwsza strona",
    strLastPage: "Ostatnia strona",
    strNextPage: "Nast?pna strona",
    strPage: "Strona {0} z {1}",
    strPrevPage: "Poprzednia strona",
    strRefresh: "Od?wie?",
    strRpp: "Wierszy na stron?: {0}"
};

