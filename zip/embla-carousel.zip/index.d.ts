export { default } from './vanilla';
export { useEmblaCarousel } from './react';
