/**
 * Copyright 2022 Design Barn Inc.
 */
declare const _default: import("lit-element").CSSResult;
export default _default;
//# sourceMappingURL=tgs-player.styles.d.ts.map