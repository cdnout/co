/**
 * Copyright 2021 Design Barn Inc.
 */
declare const _default: import("lit").CSSResult;
export default _default;
//# sourceMappingURL=lottie-player.styles.d.ts.map