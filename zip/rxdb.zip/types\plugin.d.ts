import type { RxPlugin } from './types';
export declare function addRxPlugin(plugin: RxPlugin | any): void;
