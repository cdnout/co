import crypto from './webcrypto.js';
export default crypto.getRandomValues.bind(crypto);
