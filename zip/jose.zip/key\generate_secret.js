import { generateSecret as generate } from '../runtime/generate.js';
export async function generateSecret(alg, options) {
    return generate(alg, options);
}
