import * as base64url from '../runtime/base64url.js';
export const encode = base64url.encode;
export const decode = base64url.decode;
