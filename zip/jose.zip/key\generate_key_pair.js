import { generateKeyPair as generate } from '../runtime/generate.js';
export async function generateKeyPair(alg, options) {
    return generate(alg, options);
}
