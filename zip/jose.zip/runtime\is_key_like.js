import { isCryptoKey } from './webcrypto.js';
export default (key) => {
    return isCryptoKey(key);
};
export const types = ['CryptoKey'];
