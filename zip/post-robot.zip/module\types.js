"use strict";

exports.__esModule = true;
exports.TYPES = void 0;
// export something to force webpack to see this as an ES module
const TYPES = true; // eslint-disable-next-line flowtype/require-exact-type

exports.TYPES = TYPES;