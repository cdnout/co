'use strict';

module.exports = 'data-reactid';