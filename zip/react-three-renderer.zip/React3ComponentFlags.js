"use strict";

// see ReactDOMComponentFlags

var React3ComponentFlags = {
  hasCachedChildMarkups: 1 << 0
};

module.exports = React3ComponentFlags;