"use strict";

function React3ContainerInfo(topLevelWrapper, instance) {
  // eslint-disable-line no-unused-vars
  var info = {
    _topLevelWrapper: topLevelWrapper,
    _idCounter: 1
  };

  return info;
}

module.exports = React3ContainerInfo;