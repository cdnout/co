import { TomSettings } from './types/index';
import { TomInput } from './types/index';
export default function getSettings(input: TomInput, settings_user: Partial<TomSettings>): TomSettings;
