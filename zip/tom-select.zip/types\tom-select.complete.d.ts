import TomSelect from './tom-select';
export default TomSelect;
